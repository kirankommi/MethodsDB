# SPFx MethodsDB WebPart

# Angular

# Instructions
1. Make sure you have Angular CLI installed
2. Make sure your dev env is setup for SPFx (i.e. gulp, yeoman installed globally, and run gulp trust-dev-cert on an SPFx project first)
3. Then clone this repo, run npm install, and run either gulp serve or npm start.

Everything you'd expect from a SPFx project works here,
gulp clean
gulp --ship
gulp package-solution --ship etc.

