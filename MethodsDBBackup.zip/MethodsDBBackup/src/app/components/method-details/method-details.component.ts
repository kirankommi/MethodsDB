import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { Methodetailservice } from '../../services/methodetails.service';
import { RequestTypes, Lab_centers, PlantsAffected, SampleMatrix, Priorities, lstSource_of_Request } from '../../models/RequestorModel';
import {
  lstTeamPriority, lstWorkGroupArea, lstRequestStatus, lstMethodStatus, lstClassificationReviewers, lstClassificationType,
  lstLabManagers, lstAnalyticalManagers, lstAuthors, lstTechExperts, TeamDetatails, classificationReviewersArray,
  MRLabManagerModel,
  GenericManagers
} from '../../models/TeamAdnlDtlsModel';
import { MethodDtlsModel } from '../../models/MethodDetailModel';
import { PeoplePickerUser } from '../../interfaces/people-picker-query';
import { MethodNotes } from '../../models/MethodDetailModel';
import { from } from 'rxjs/observable/from';
import { AlertMessage } from '../../services/alertmessage.service';
import { MessageService } from 'primeng/api';
import { AppServiceService } from '../../shared/app-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-method-details',
  templateUrl: './method-details.component.html',
  styleUrls: ['./method-details.component.css']
})
export class MethodDetailsComponent implements OnInit {
  @Input() context: WebPartContext;
  mainTab: string = "RequestorZone";
  sub: any;
  Id: string;
  currentWebUrl: string = '';
  methodRequest: MethodDtlsModel;
  Notes: MethodNotes[];
  FullNotesList: MethodNotes[];
  searchDescription: string;
  description: string;
  Change_Requested: string = "";
  Problem_Statement: string = "";
  Additional_Info: string;
  Request_TypeId: string;
  PriorityId: string;
  Date_Requested: Date;
  Requester: string;
  Phone: number;
  RequestorEmail: string;
  SchedA_934_Eng: boolean;
  Tech_Service: boolean;
  Manufacturing: boolean;
  Instrumentation: boolean;
  Training: boolean;
  Others: boolean;
  OthersData: string;
  Project_Activity: string;
  Cost_Center: string;
  Title: string;
  otherChecked = false;
  spusers: PeoplePickerUser[] = [];
  lstSampleMatrix: SampleMatrix[];
  lstlabcenters: Lab_centers[];
  lstSourceofRequest: lstSource_of_Request[];
  lstPlantsAffected: PlantsAffected[];
  lstRequestTypes: RequestTypes[];
  lstPriorities: Priorities[];
  SourceOfReqTitle: string;
  RequestTypTitle: string;
  priorityTitle: string;
  plantsEff: string[] = [];
  AreasEffTitle: string[] = [];
  SamMatrix: string[] = [];
  LabCetr: string[] = [];
  NoteSaved: string = "Note saved successfully";
  Edit_Saved: string = 'Data inserted successfully';
  Source_of_RequestId: string;
  Priority_Id: string;
  Request_Changed_Id: string;
  RequestTypes: string;
  SampleMatrix: string;
  Lab_centers: string;
  PlantsAffected: string;
  Priorities: string;
  NotesDate: Date;
  NotesDefaultDate = new Date();
  selectedSampleMatrix: SampleMatrix[] = [];
  selectedPlantsAffected: PlantsAffected[] = [];
  selectedLabCenters = [];
  Requester_Edit: boolean = true;
  Otherchecked: boolean = false;
  intselectedPlantsAffected: number[] = [];
  intselectedLabCenters: number[] = [];
  intselectedSampleMatrix: number[] = [];
  IsMethodCoordinator: boolean = false;
  IsMethodRequestor: boolean = false;
  desiredLimitDection: string;
  ExcpectedMatrix_Stream: string;
  Matrix_StreamComposition: string;
  business_need: string;
  Safety_Concern: string;
  lstTeamPriority: lstTeamPriority[] = [];
  lstWorkGroupArea: lstWorkGroupArea[] = [];
  lstRequestStatus: lstRequestStatus[] = [];
  lstMethodStatus: lstMethodStatus[] = [];
  lstClassificationReviewers: lstClassificationReviewers[] = [];
  lstClassificationType: lstClassificationType[] = [];
  lstLabManagers: lstLabManagers[] = [];
  lstAnalyticalManagers: lstAnalyticalManagers[] = [];
  lstAuthors: lstAuthors[] = [];
  lstTechExperts: lstTechExperts[] = [];
  classRev2: boolean = false;
  teamDetatails: TeamDetatails = null;
  TechArea: string;
  TechDeliveryDate: Date;
  TeamPriorityId: number;
  WorkGroupAreaId: number;
  RequestStatusId: number;
  MethodNo: string;
  VersionNo: string;
  Classification: string;
  ReValidation: string;
  MethodType: string;
  MethodStatusId: number;
  ClassificationReviewers: string;
  MRAnalyticalManager: string;
  MRAuthor: string;
  MRTechExperts: string;
  MALabManager: string;
  MAAnalyticalManager: string;
  MAAuthor: string;
  MATechExperts: string;
  classificationReviewersList: classificationReviewersArray[] = [];
  MethodReviewersTechExperts: classificationReviewersArray[] = [];
  MethodApproversTechExperts: classificationReviewersArray[] = [];
  MRLabManager: MRLabManagerModel = new MRLabManagerModel();
  selectedClassificationRvs: classificationReviewersArray[] = [];
  selectedMRTechExperts: classificationReviewersArray[] = [];
  selectedMATechExperts: classificationReviewersArray[] = [];
  public users: { value: number, label: number }[] = [];
  public MRExperts: { value: number, label: number }[] = [];
  public MAExperts: { value: number, label: number }[] = [];
  selectedMRLabManager: number;
  MRManagers: GenericManagers[] = [];
  IsMRLabManagerRequired: boolean = false;
  selectedMRAnalyticalManager: number;
  MRAnalyticalManagers: GenericManagers[] = [];
  IsMRAnalyticalManagerRequired: boolean = false;
  selectedMRAuthor: number;
  MRAuthors: GenericManagers[] = [];
  MAAuthors: GenericManagers[] = [];
  IsMRAuthorRequired: boolean = false;
  selectedMALabManager: number;
  IsMALabManagerRequired: boolean = false;
  selectedMAAnalyticalManager: number;
  IsMAAnalyticalManagerRequired: boolean = false;
  selectedMAAuthor: number;
  IsMAAuthorRequired: boolean = false;
  TeamTitle: string;
  TeamId:number;
  Indicator:string = "#000000";
  data: any;
  options: any;
  uploadedFiles: any[] = [];
  uploadDisplay:boolean = false;
  fileToUpload: File = null;
  filename: string;
  filesize: string;
  public siteUrl: string;  
  public siteRelativeUrl: string;
  timeLineStages: number[] = [];

  constructor(private route: ActivatedRoute,
    public methodetailservice: Methodetailservice,
    private alertMessage: AlertMessage,
    private router: Router,
    private messageService: MessageService, private appService: AppServiceService) {
      
  }

  ngOnInit() {
    this.context = window["webPartContext"];
    this.currentWebUrl = this.context.pageContext.web.absoluteUrl;
    this.sub = this.route.params.subscribe(params => {
      this.Id = params['Id'];
      if (this.Id != undefined || this.Id != null) {
        this.init();
      }
    });
    let userGroups: any;
    userGroups = this.appService.getFromLocal('userGroups');
    this.IsMethodCoordinator = userGroups.includes('MethodCoOrdinators');
    this.IsMethodRequestor = userGroups.includes('Requestors');
    this.messageService.clear();
  }

  async init() {
    await this.getLists();
    this.getNotesList();
    await this.getListsData();
    this.getTeamsbyId();
    
    //this.getRequstbyId(this.Id);
  }

  addDataToTimelinesReport(){
    this.data = {
      labels: ['Request Accepted ', 'Draft Stage ', 'Review Stage ', 'Approval Stage ', 'Tech Report Submission'],
      datasets: [
          {
              label:'',
              backgroundColor: '#42A5F5',
              borderColor: '#1E88E5',
              data: this.timeLineStages,
          },
          
      ]
    }

    this.options = {
      title: {
          display: true,
          text: 'No of Days',
          fontSize: 16,
          position: 'left'
      },
      legend: {
          display:true,
          position: 'bottom'
      }
    }
  }

  getRequstbyId(Id: string) {
    let requestLibrary = 'lstMethodRequest';
    let requestUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + requestLibrary + "'" + ')/items(' + Id + ')')
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null) {
              this.methodRequest = responseJSON;
              this.Problem_Statement = this.methodRequest.Problem_Statement;
              this.Change_Requested = this.methodRequest.Change_Requested;
              this.Additional_Info = this.methodRequest.Additional_Info;
              this.Request_TypeId = this.methodRequest.Request_TypeId;
              this.PriorityId = this.methodRequest.PriorityId;
              this.Date_Requested = this.methodRequest.Date_Requested;
              this.Requester = this.methodRequest.Requester;
              this.RequestorEmail = this.methodRequest.RequestorEmail;
              this.Phone = this.methodRequest.Phone;
              this.Project_Activity = this.methodRequest.Project_Activity;
              this.Cost_Center = this.methodRequest.Cost_Center;
              this.Title = this.methodRequest.Title;
              this.SchedA_934_Eng = this.methodRequest.SchedA_934_Eng;
              this.Tech_Service = this.methodRequest.Tech_Service;
              this.Manufacturing = this.methodRequest.Manufacturing;
              this.Instrumentation = this.methodRequest.Instrumentation;
              this.Others = this.methodRequest.Others;
              this.OthersData = this.methodRequest.OthersData;
              this.Training = this.methodRequest.Training;
              this.Source_of_RequestId = this.methodRequest.Source_of_RequestId;
              this.Priority_Id = this.methodRequest.PriorityId;
              this.Request_Changed_Id = this.methodRequest.Request_TypeId;
              this.desiredLimitDection = this.methodRequest.Component_Limit_of_Detection;
              this.ExcpectedMatrix_Stream = this.methodRequest.Matrix_StreamConcentrationRange;
              this.Matrix_StreamComposition = this.methodRequest.Matrix_StreamComposition;
              this.business_need = this.methodRequest.Business_Need;
              this.Safety_Concern = this.methodRequest.Safety_concerns;

              for (let i = 0; i < this.lstSourceofRequest.length; i++) {
                if (this.methodRequest.Source_of_RequestId == this.lstSourceofRequest[i].Id.toString()) {
                  this.SourceOfReqTitle = this.lstSourceofRequest[i].Title;
                }
              }

              for (let i = 0; i < this.lstRequestTypes.length; i++) {
                if (this.methodRequest.Request_TypeId == this.lstRequestTypes[i].Id.toString()) {
                  this.RequestTypTitle = this.lstRequestTypes[i].Title
                }
              }

              for (let i = 0; i < this.lstPriorities.length; i++) {
                if (this.methodRequest.PriorityId == this.lstPriorities[i].Id.toString()) {
                  this.priorityTitle = this.lstPriorities[i].Title
                }
              }

              this.selectedPlantsAffected = [];
              this.plantsEff = [];
              if (this.methodRequest.PlantsAffectedId != null || this.methodRequest.PlantsAffectedId != undefined) {
                for (let i = 0; i < this.methodRequest.PlantsAffectedId.length; i++) {
                  this.selectedPlantsAffected.push({ Id: Number(this.methodRequest.PlantsAffectedId[i]), Title: '' });
                  for (let j = 0; j < this.lstPlantsAffected.length; j++) {
                    if (this.lstPlantsAffected[j].Id == this.methodRequest.PlantsAffectedId[i]) {
                      this.plantsEff.push(this.lstPlantsAffected[j].Title);
                    }
                  }
                }
              }

              this.selectedLabCenters = [];
              this.LabCetr = [];
              if (this.methodRequest.LabCentersId != null || this.methodRequest.LabCentersId != undefined) {
                for (let i = 0; i < this.methodRequest.LabCentersId.length; i++) {
                  this.selectedLabCenters.push({ Id: Number(this.methodRequest.LabCentersId[i]), Title: '' });
                  for (let j = 0; j < this.lstlabcenters.length; j++) {
                    if (this.lstPlantsAffected[j].Id == this.methodRequest.LabCentersId[i]) {
                      this.LabCetr.push(this.lstlabcenters[j].Title);
                    }
                  }
                }
              }

              this.selectedSampleMatrix = [];
              this.SamMatrix = [];
              for (let i = 0; i < this.methodRequest.Sample_MatrixId.length; i++) {
                if (this.methodRequest.Sample_MatrixId != null || this.methodRequest.Sample_MatrixId != undefined) {
                  this.selectedSampleMatrix.push({ Id: Number(this.methodRequest.Sample_MatrixId[i]), Title: '' });
                  for (let j = 0; j < this.lstSampleMatrix.length; j++) {
                    if (this.lstSampleMatrix[j].Id == this.methodRequest.Sample_MatrixId[i]) {
                      this.SamMatrix.push(this.lstSampleMatrix[j].Title);
                    }
                  }
                }
              }

              this.AreasEffTitle = [];
              if (this.methodRequest.SchedA_934_Eng) {
                this.AreasEffTitle.push("Sched A/934-Eng");
              }
              if (this.methodRequest.Tech_Service) {
                this.AreasEffTitle.push("Techservice");
              }

              if (this.methodRequest.Manufacturing) {
                this.AreasEffTitle.push("Manufacturing");
              }

              if (this.methodRequest.Instrumentation) {
                this.AreasEffTitle.push("Instrumentation");
              }

              if (this.methodRequest.Training) {
                this.AreasEffTitle.push("Training");
              }

              if (this.methodRequest.Others) {
                this.AreasEffTitle.push(this.methodRequest.OthersData);
              }

              //Timelines report
              if(responseJSON.Date_Requested != null && responseJSON.Date_Draft != null) {
                this.timeLineStages.push(0 + this.daysDiff(new Date(responseJSON.Date_Requested), new Date(responseJSON.Date_Draft))); 
              }
              else{
                this.timeLineStages.push(0);
              }

              if(responseJSON.Date_Draft != null && responseJSON.Date_Review != null) {
                this.timeLineStages.push(0 + this.daysDiff(new Date(responseJSON.Date_Draft), new Date(responseJSON.Date_Review))); 
              }
              else{
                this.timeLineStages.push(0);
              }

              if(responseJSON.Date_Review != null && responseJSON.Date_Approve != null) {
                this.timeLineStages.push(0 + this.daysDiff(new Date(responseJSON.Date_Review), new Date(responseJSON.Date_Approve))); 
              }
              else{
                this.timeLineStages.push(0);
              }

              if(responseJSON.Date_Approve != null && responseJSON.Date_Publish != null) {
                this.timeLineStages.push(0 + this.daysDiff(new Date(responseJSON.Date_Approve), new Date(responseJSON.Date_Publish))); 
              }
              else{
                this.timeLineStages.push(0);
              }

              if(responseJSON.Date_Publish != null && responseJSON.Date_TechReport != null) {
                this.timeLineStages.push(0 + this.daysDiff(new Date(responseJSON.Date_Publish), new Date(responseJSON.Date_TechReport))); 
              }
              else{
                this.timeLineStages.push(0);
              }
              
              this.addDataToTimelinesReport();  
            }
          });
        }
      });
  }

  daysDiff(dateFrom, dateTo) {
      var diff = Math.abs(dateFrom.getTime() - dateTo.getTime());
      var diffDays = Math.ceil(diff / (1000 * 3600 * 24)); 

      return diffDays
   }

  getLists() {
    let SampleMatrixitems = 'lstSampleMatrix';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + SampleMatrixitems + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstSampleMatrix = responseJSON.value;

            }
          });
        }
      });

    let LabCenters = 'lstLabCenter';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + LabCenters + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstlabcenters = responseJSON.value;
            }
          });
        }
      });

    let Source_of_Request = 'lstSource_of_Request';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + Source_of_Request + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstSourceofRequest = responseJSON.value;
            }
          });
        }
      });

    let PlantsAffected = 'lstPlantsAffected';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + PlantsAffected + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstPlantsAffected = responseJSON.value;
            }
          });
        }
      });

    let requestype = 'lstRequestType';;
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + requestype + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstRequestTypes = responseJSON.value;
            }
          });
        }
      });

    let Priority = 'lstPriority';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + Priority + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstPriorities = responseJSON.value;

              this.getRequstbyId(this.Id);
            }
          });
        }
      });


  }

  AddNote($event, op) {
    op.toggle($event, op);
    this.Note_Reset()
  }

  async SaveNotes($event, op) {
    if (this.description != '' &&
      this.description != null &&
      this.description != undefined &&
      this.NotesDate != null && this.NotesDate != undefined

    ) {
      op.toggle($event, op);
      await this.methodetailservice.SaveNotes(this.Id, this.NotesDate, this.description, this.Indicator);
      this.messageService.clear();
      this.messageService.add({ severity: 'success', summary: '', detail: this.NoteSaved });
      this.getNotesList();
    }
    else {
      this.messageService.clear();
      this.messageService.add({ severity: 'warn', summary: '', detail: 'Please fill the required fields ' });
    }
  }

  getNotesList() {
    let lstNotes = 'lstMethodNotes';
    let Title = this.Id;
    let requestUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + lstNotes + "'" + ')/items?$filter=Title eq ' + this.Id)
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.Notes = responseJSON.value;
              this.FullNotesList = responseJSON.value;
              this.Notes.sort((a, b) => b.Id - a.Id);
            }
          });
        }
      });
  }

  Search_Notes() {
    this.Notes = []
    this.Notes = this.FullNotesList;
    if (this.searchDescription != '' && this.searchDescription != null && this.searchDescription != undefined) {
      this.Notes = this.Notes.filter(s => (s.Description.toLocaleLowerCase().includes(this.searchDescription.toLocaleLowerCase().trim())));
    }
  }

  Search_Clear() {
    this.searchDescription = null;
    this.getNotesList();

  }

  Note_Reset() {
    this.description = null;
    this.NotesDate = new Date();
  }

  toggleOther(event) {
    if (event) {
      this.Otherchecked = true;
    }
    else if (!event) {
      this.Otherchecked = false;
    }
  }

  isDataValid() {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    let req = this.methodRequest.RequestorEmail;
    //requestor zone validation
    if (this.selectedSampleMatrix.length == null || this.selectedSampleMatrix.length == 0) {
      return false;
    }
    if (this.Project_Activity == null && this.Cost_Center == null) {
      return false;
    }
    if (!this.SchedA_934_Eng &&
      !this.Tech_Service &&
      !this.Manufacturing &&
      !this.Instrumentation &&
      !this.Training &&
      !this.Others) {
      return false;
    }
    else if (
      this.Request_Changed_Id == null ||
      this.Request_Changed_Id == "" ||
      this.Priority_Id == null ||
      this.Priority_Id == "" ||
      this.Title == null ||
      this.Problem_Statement == null ||
      !req.match(mailformat)
    ) {
      return false;
    }//team details validation
    if(this.TechArea == null || 
      this.TechArea.trim() == '' ||
      this.WorkGroupAreaId == null || 
      this.WorkGroupAreaId == -1 || 
      this.selectedMRLabManager == null || 
      this.selectedMRAnalyticalManager == null ||
      this.selectedMRAuthor == null ||
      this.selectedMALabManager == null ||
      this.selectedMAAnalyticalManager == null ||
      this.selectedMAAuthor == null){
      return false
    }
    return true;
  }


  SaveAccept() {
    let classrev = JSON.stringify(this.classificationReviewersList);
    let mrtech = JSON.stringify(this.MethodReviewersTechExperts);
    let matech = JSON.stringify(this.MethodApproversTechExperts);

    let Teamlist = "lstTeamAdditionalDtls";

    if (this.isDataValid()) {
      if (this.selectedPlantsAffected.length != undefined) {
        for (let i = 0; i < this.selectedPlantsAffected.length; i++) {
          this.intselectedPlantsAffected.push(this.selectedPlantsAffected[i].Id)
        }
      }

      if (this.selectedLabCenters.length != undefined) {
        for (let i = 0; i < this.selectedLabCenters.length; i++) {
          this.intselectedLabCenters.push(this.selectedLabCenters[i].Id)
        }
      }

      if (this.selectedSampleMatrix.length != undefined) {
        for (let i = 0; i < this.selectedSampleMatrix.length; i++) {
          this.intselectedSampleMatrix.push(this.selectedSampleMatrix[i].Id)
        }
      }

      let plantsAffected = { "results": this.intselectedPlantsAffected };
      const body: string = JSON.stringify({
        'Title': `${this.Title}`,
        'SchedA_934_Eng': `${this.SchedA_934_Eng}`,
        'Tech_Service': `${this.Tech_Service}`,
        'Manufacturing': `${this.Manufacturing}`,
        'Instrumentation': `${this.Instrumentation}`,
        'Training': `${this.Training}`,
        'Others': `${this.Others}`,
        'OthersData': `${this.OthersData}`,
        'LabCentersId': this.intselectedLabCenters,
        'PlantsAffectedId': this.intselectedPlantsAffected,
        'Request_TypeId': `${this.Request_Changed_Id}`,
        'PriorityId': `${this.Priority_Id}`,
        'Source_of_RequestId': `${this.Source_of_RequestId}`,
        'Sample_MatrixId': this.intselectedSampleMatrix,
        'Project_Activity': `${this.Project_Activity}`,
        'Cost_Center': `${this.Cost_Center}`,
        'Problem_Statement': `${this.Problem_Statement == null ? "" : this.Problem_Statement}`,
        'Change_Requested': `${this.Change_Requested == null ? "" : this.Change_Requested}`,
        'Additional_Info': `${this.Additional_Info == null ? "" : this.Additional_Info}`,
        'Safety_concerns': `${this.Safety_Concern == null ? "" : this.Safety_Concern}`,
        'Business_Need': `${this.business_need}`,
        'Component_Limit_of_Detection': `${this.desiredLimitDection}`,
        'Matrix_StreamComposition': `${this.ExcpectedMatrix_Stream}`,
        'Matrix_StreamConcentrationRange': `${this.Matrix_StreamComposition}`,
      });

      let ReqZonelist = "lstMethodRequest";
      this.context.spHttpClient.post(`${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${ReqZonelist}')/items(${this.Id})`,
        SPHttpClient.configurations.v1,
        {
          headers: {
            'Accept': 'application/json;odata=nometadata',
            'Content-type': 'application/json;odata=nometadata',
            'odata-version': '',
            'IF-MATCH': '*',
            'X-HTTP-Method': 'MERGE'
          },
          body: body
        })
        .then((response: SPHttpClientResponse): void => {
          //Edit teamlist
            if (this.TeamTitle != null && this.TeamTitle != undefined) {
              const body1: string = JSON.stringify({
                'Title': `${(this.TeamTitle == null || this.TeamTitle == undefined) ? this.Id : this.TeamTitle}`,
                'TechArea': `${this.TechArea}`,
                'TechDeliveryDate': `${(this.TechDeliveryDate  == null || this.TechDeliveryDate == undefined) ? "" : this.TechDeliveryDate}`,
                'PriorityId': `${this.TeamPriorityId}`,
                'WorkGroupAreaId': `${this.WorkGroupAreaId}`,
                'RequestStatusId': `${this.RequestStatusId}`,
                'ReValidation': `${this.ReValidation}`,
                'MethodStatusId': `${this.MethodStatusId}`,
                'ClassificationReviewers': `${classrev}`,
                'MRLabManagerId': `${this.selectedMRLabManager}`,
                'IsMRLabManagerRequired': `${this.IsMRLabManagerRequired}`,
                'MRAnalyticalManagerId': `${this.selectedMRAnalyticalManager}`,
                'IsMRAnalyticalManagerRequired': `${this.IsMRAnalyticalManagerRequired}`,
                'MRAuthorId': `${this.selectedMRAuthor}`,
                'IsMRAuthorRequired': `${this.IsMRAuthorRequired}`,
                'MALabManagerId': `${this.selectedMALabManager}`,
                'IsMALabManagerRequired': `${this.IsMALabManagerRequired}`,
                'MAAnalyticalManagerId': `${this.selectedMAAnalyticalManager}`,
                'IsMAAnalyticalManagerRequired': `${this.IsMAAnalyticalManagerRequired}`,
                'MAAuthorId': `${this.selectedMAAuthor}`,
                'IsMAAuthorRequired': `${this.IsMAAuthorRequired}`,
                'MRTechExperts': `${mrtech}`,
                'MATechExperts': `${matech}`,
              });
              console.log(body1);
              this.context.spHttpClient.post(`${this.context.pageContext.web.absoluteUrl}/_api/web/lists/getbytitle('${Teamlist}')/items(${this.TeamId})`,
                SPHttpClient.configurations.v1,
                {
                  headers: {
                    'Accept': 'application/json;odata=nometadata',
                    'Content-type': 'application/json;odata=nometadata',
                    'odata-version': '',
                    'IF-MATCH': '*',
                    'X-HTTP-Method': 'MERGE'
                  },
                  body: body1
                })
                .then((response: SPHttpClientResponse): void => {
                  if(response.ok) {
                    this.router.navigateByUrl('/dashboard');
                    this.messageService.clear();
                    this.messageService.add({ severity: 'success', summary: '', detail: this.Edit_Saved });
                  }
                }, (error: any): void => {

                });
            }
            else { //save team list
              const body2: string = JSON.stringify({
                '__metadata': {
                  'type': 'SP.Data.LstTeamAdditionalDtlsListItem'
                },
                'Title': `${(this.TeamTitle == null || this.TeamTitle == undefined) ? this.Id : this.TeamTitle}`,
                'TechArea': `${this.TechArea}`,
                'TechDeliveryDate': `${(this.TechDeliveryDate  == null || this.TechDeliveryDate == undefined) ? "" : this.TechDeliveryDate}`,
                'PriorityId': `${this.TeamPriorityId}`,
                'WorkGroupAreaId': `${this.WorkGroupAreaId}`,
                'RequestStatusId': `${this.RequestStatusId}`,
                'ReValidation': `${this.ReValidation}`,
                'MethodStatusId': `${this.MethodStatusId}`,
                'ClassificationReviewers': `${classrev}`,
                'MRLabManagerId': `${this.selectedMRLabManager}`,
                'IsMRLabManagerRequired': `${this.IsMRLabManagerRequired}`,
                'MRAnalyticalManagerId': `${this.selectedMRAnalyticalManager}`,
                'IsMRAnalyticalManagerRequired': `${this.IsMRAnalyticalManagerRequired}`,
                'MRAuthorId': `${this.selectedMRAuthor}`,
                'IsMRAuthorRequired': `${this.IsMRAuthorRequired}`,
                'MALabManagerId': `${this.selectedMALabManager}`,
                'IsMALabManagerRequired': `${this.IsMALabManagerRequired}`,
                'MAAnalyticalManagerId': `${this.selectedMAAnalyticalManager}`,
                'IsMAAnalyticalManagerRequired': `${this.IsMAAnalyticalManagerRequired}`,
                'MAAuthorId': `${this.selectedMAAuthor}`,
                'IsMAAuthorRequired': `${this.IsMAAuthorRequired}`,
                'MRTechExperts': `${mrtech}`,
                'MATechExperts': `${matech}`,
              });
              this.methodetailservice.SaveTeamDetails(body2).then((response: SPHttpClientResponse): void => {
                this.router.navigateByUrl('/dashboard');
                this.messageService.clear();
                this.messageService.add({ severity: 'success', summary: '', detail: this.Edit_Saved });
              }, (error: any): void => {
              });
            }
        }, (error: any): void => {
        });
    }
    else {
      this.messageService.clear();
      this.messageService.add({ severity: 'warn', summary: '', detail: 'Please fill in all the required fields' });
    }
  }

  Cancel() {
    this.Requester_Edit = true;
    this.init();
  }

  getTeamsbyId() {
    let requestLibrary = 'lstTeamAdditionalDtls';
    let requestUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + requestLibrary + "'" + ')/items?$filter=Title eq ' + this.Id)
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON.value.length != 0) {
              console.log(responseJSON.value[0]);
              this.TeamId = responseJSON.value[0].Id;
              this.TeamTitle = responseJSON.value[0].Title;
              this.teamDetatails = responseJSON.value[0];
              this.TechArea = responseJSON.value[0].TechArea;
              if(responseJSON.value[0].TechDeliveryDate != null){
                this.TechDeliveryDate = new Date(responseJSON.value[0].TechDeliveryDate);
              }
              else{
                this.TechDeliveryDate = null;
              }
              this.TeamPriorityId = responseJSON.value[0].PriorityId;
              this.WorkGroupAreaId = responseJSON.value[0].WorkGroupAreaId;
              this.RequestStatusId = responseJSON.value[0].RequestStatusId;
              this.MethodNo = responseJSON.value[0].MethodNo;
              this.VersionNo = responseJSON.value[0].VersionNo;
              this.Classification = responseJSON.value[0].Classification;
              this.MethodType = responseJSON.value[0].MethodType;
              this.ReValidation = responseJSON.value[0].ReValidation;
              this.MethodStatusId = responseJSON.value[0].MethodStatusId;
              this.selectedMRLabManager = responseJSON.value[0].MRLabManagerId;
              this.IsMRLabManagerRequired = responseJSON.value[0].IsMRLabManagerRequired;
              this.selectedMRAnalyticalManager = responseJSON.value[0].MRAnalyticalManagerId;
              this.IsMRAnalyticalManagerRequired = responseJSON.value[0].IsMRAnalyticalManagerRequired;
              this.selectedMRAuthor = responseJSON.value[0].MRAuthorId;
              this.IsMRAuthorRequired = responseJSON.value[0].IsMRAuthorRequired;
              this.selectedMALabManager = responseJSON.value[0].MALabManagerId;
              this.IsMALabManagerRequired = responseJSON.value[0].IsMALabManagerRequired;
              this.selectedMAAnalyticalManager = responseJSON.value[0].MAAnalyticalManagerId;
              this.IsMAAnalyticalManagerRequired = responseJSON.value[0].IsMAAnalyticalManagerRequired;
              this.selectedMAAuthor = responseJSON.value[0].MAAuthorId;
              this.IsMAAuthorRequired = responseJSON.value[0].IsMAAuthorRequired;
              this.classificationReviewersList = JSON.parse(responseJSON.value[0].ClassificationReviewers);
              this.MethodApproversTechExperts = JSON.parse(responseJSON.value[0].MATechExperts);
              this.MethodReviewersTechExperts = JSON.parse(responseJSON.value[0].MRTechExperts);

              if (this.classificationReviewersList == null) {
                this.classificationReviewersList=[];
                this.classificationReviewersList.push({ RowId: this.classificationReviewersList.length, Id: null, Type: null, Reply: null, Email: null, Title: null });

              }
              if (this.MethodApproversTechExperts == null) {
                this.MethodApproversTechExperts = []
                this.MethodApproversTechExperts.push({ RowId: this.MethodApproversTechExperts.length, Id: null, Type: null, Reply: null, Email: null, Title: null });

              }
              if (this.MethodReviewersTechExperts == null) {
                this.MethodReviewersTechExperts = [];
                this.MethodReviewersTechExperts.push({ RowId: this.MethodReviewersTechExperts.length, Id: null, Type: null, Reply: null, Email: null, Title: null });

              }
            }
            else
            {
              this.TeamId = null;
              this.TeamTitle = null;
              this.teamDetatails = null;
              this.TechArea = null;
              this.TechDeliveryDate = null;
              this.TeamPriorityId = -1;
              this.WorkGroupAreaId = -1;
              this.RequestStatusId = -1;
              this.MethodNo = null;
              this.VersionNo = null;
              this.Classification = null;
              this.MethodType = null;
              this.ReValidation = null;
              this.MethodStatusId = -1;
              this.selectedMRLabManager = null;
              this.IsMRLabManagerRequired = false;
              this.selectedMRAnalyticalManager = null;
              this.IsMRAnalyticalManagerRequired = false;
              this.selectedMRAuthor = null;
              this.IsMRAuthorRequired = false;
              this.selectedMALabManager = null;
              this.IsMALabManagerRequired = false;
              this.selectedMAAnalyticalManager = null;
              this.IsMAAnalyticalManagerRequired = false;
              this.selectedMAAuthor = null;
              this.IsMAAuthorRequired = false;

              if (this.classificationReviewersList.length == 0) {
                this.classificationReviewersList.push({ RowId: this.classificationReviewersList.length, Id: null, Type: null, Reply: null, Email: null, Title: null });

              }
              if (this.MethodApproversTechExperts.length == 0) {
                this.MethodApproversTechExperts.push({ RowId: this.MethodApproversTechExperts.length, Id: null, Type: null, Reply: null, Email: null, Title: null });

              }
              if (this.MethodReviewersTechExperts.length == 0) {
                this.MethodReviewersTechExperts.push({ RowId: this.MethodReviewersTechExperts.length, Id: null, Type: null, Reply: null, Email: null, Title: null });

              }
              this.selectedClassificationRvs = this.processDynamicControls(this.classificationReviewersList, this.selectedClassificationRvs);
              this.selectedMRTechExperts = this.processDynamicControls(this.MethodReviewersTechExperts, this.selectedMRTechExperts);
              this.selectedMATechExperts = this.processDynamicControls(this.MethodApproversTechExperts, this.selectedMATechExperts);
              let picked = [];
              this.classificationReviewersList.forEach(row => {
                if (picked.indexOf(row.Id) === -1) {
                  picked.push(row.Id);
                  this.users.push({ label: row.Id, value: row.Id });
                  this.selectedClassificationRvs.push(row);
                }
              });

              let mrPicked = [];
              this.MethodReviewersTechExperts.forEach(row => {
                if (mrPicked.indexOf(row.Id) === -1) {
                  mrPicked.push(row.Id);
                  // this.users.push({ label: row.Id, value: row.Id });
                  this.selectedMRTechExperts.push(row);
                }
              });

              let maPicked = [];
              this.MethodApproversTechExperts.forEach(row => {
                if (maPicked.indexOf(row.Id) === -1) {
                  maPicked.push(row.Id);
                  // this.users.push({ label: row.Id, value: row.Id });
                  this.selectedMATechExperts.push(row);
                }
              });
            }
          });
        }
      });
  }
  processDynamicControls(reviewers: classificationReviewersArray[], selected: classificationReviewersArray[]):
    classificationReviewersArray[] {
    let picked = [];
    reviewers.forEach(row => {
      if (picked.indexOf(row.Id) === -1) {
        this.users.push({ label: row.Id, value: row.Id });
        picked.push(row.Id);
        selected.push({ RowId: selected.length+1,
          Id: row.Id,
          Type: row.Type,
          Reply: row.Reply,
          Email: row.Email,
          Title: row.Title});
      }
    });
    return selected;
  }

  getListsData() {
    let TeamPriority = 'lstTeamPriority';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + TeamPriority + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstTeamPriority = responseJSON.value;
            }
          });
        }
      });

    let WorkGroupArea = 'lstWorkGroupArea';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + WorkGroupArea + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstWorkGroupArea = responseJSON.value;
            }
          });
        }
      });

    let RequestStatus = 'lstRequestStatus';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + RequestStatus + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstRequestStatus = responseJSON.value;
            }
          });
        }
      });

    let MethodStatus = 'lstMethodStatus';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + MethodStatus + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstMethodStatus = responseJSON.value;
            }
          });
        }
      });

    let ClassificationReviewers = 'ClassificationReviewers';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/SiteGroups/GetByName(' + "'" + ClassificationReviewers + "'" + ')/users'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstClassificationReviewers = responseJSON.value;
            }
          });
        }
      });

    let ClassificationType = 'lstClassificationType';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + ClassificationType + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstClassificationType = responseJSON.value;
            }
          });
        }
      });

    let LabManagers = 'LabManagers';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/SiteGroups/GetByName(' + "'" + LabManagers + "'" + ')/users'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstLabManagers = responseJSON.value;
              this.lstLabManagers.forEach(element => {
                this.MRManagers.push({ label: element.Title, value: element.Id })
              });
            }
          });
        }
      });

    let AnalyticalManagers = 'AnalyticalManagers';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/SiteGroups/GetByName(' + "'" + AnalyticalManagers + "'" + ')/users'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstAnalyticalManagers = responseJSON.value;
              this.lstAnalyticalManagers.forEach(element => {
                this.MRAnalyticalManagers.push({ label: element.Title, value: element.Id })
              });
            }

          });
        }
      });

    let Authors = 'Authors';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/SiteGroups/GetByName(' + "'" + Authors + "'" + ')/users'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstAuthors = responseJSON.value;
              this.lstAuthors.forEach(element => {
                this.MRAuthors.push({ label: element.Title, value: element.Id })
                this.MAAuthors.push({ label: element.Title, value: element.Id })
              });
            }
          });
        }
      });

    let TechExperts = 'TechExperts';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/SiteGroups/GetByName(' + "'" + TechExperts + "'" + ')/users'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              debugger;
              this.lstTechExperts = responseJSON.value;
            }
          });
        }
      });

  }

  AddNewClassRevr(event) {

    let picked = [];
    this.classificationReviewersList.forEach(row => {
      if (picked.indexOf(row.Id) === -1) {
        picked.push(row.Id);
        this.users.push({ label: row.Id, value: row.Id });
      }
    });
    if (this.classificationReviewersList.length < this.lstClassificationReviewers.length) {
    this.selectedClassificationRvs.push({ RowId: this.classificationReviewersList.length + 1, Id: null, Type: null, Reply: null, Email: null, Title: null });

      this.classificationReviewersList.push({ RowId: this.classificationReviewersList.length + 1, Id: null, Type: null, Reply: null, Email: null, Title: null });
    }
  }
  AddNewMRExpert(event) {
    let picked = [];
    this.MethodReviewersTechExperts.forEach(row => {
      if (picked.indexOf(row.Id) === -1) {
        picked.push(row.Id);
        this.users.push({ label: row.Id, value: row.Id });
      }
    });
    if (this.MethodReviewersTechExperts.length < this.lstTechExperts.length) {
      this.selectedMRTechExperts.push({ RowId: this.MethodReviewersTechExperts.length + 1, Id: null, Type: null, Reply: null, Email: null, Title: null });
      this.MethodReviewersTechExperts.push({ RowId: this.MethodReviewersTechExperts.length + 1, Id: null, Type: null, Reply: null, Email: null, Title: null });
    }
  }
  AddNewMAExpert(event) {
    let picked = [];
    this.MethodApproversTechExperts.forEach(row => {
      if (picked.indexOf(row.Id) === -1) {
        picked.push(row.Id);
        this.users.push({ label: row.Id, value: row.Id });
      }
    });
    if (this.MethodApproversTechExperts.length < this.lstClassificationReviewers.length) {
      this.selectedMATechExperts.push({ RowId: this.MethodApproversTechExperts.length + 1, Id: null, Type: null, Reply: null, Email: null, Title: null });
      this.MethodApproversTechExperts.push({ RowId: this.MethodApproversTechExperts.length + 1, Id: null, Type: null, Reply: null, Email: null, Title: null });
    }
  }

  DeleteClassRevr(rowId: any) {
    let picked = [];
    this.users = [];
    this.classificationReviewersList.forEach(row => {
      if (picked.indexOf(row.Id) === -1) {
        picked.push(row.Id);
        this.users.push({ label: row.Id, value: row.Id });
      }
    });
    if (this.classificationReviewersList.length != 1) {
      this.classificationReviewersList = this.classificationReviewersList.filter((i: any) => i.RowId != rowId);
      for (var i = 0; i < this.classificationReviewersList.length; i++) {
        this.classificationReviewersList[i].RowId = i + 1;
      }
    }
  }

  classReviewerChange(event, index) {
    this.classificationReviewersList[index].Id = event.value.Id;
    this.classificationReviewersList[index].Email = event.value.Email;
    this.classificationReviewersList[index].Title = event.value.Title;
  }

  DeleteMATechExpert(rowId: any) {
    let picked = [];
    this.users = [];
    this.MethodApproversTechExperts.forEach(row => {
      if (picked.indexOf(row.Id) === -1) {
        picked.push(row.Id);
        this.users.push({ label: row.Id, value: row.Id });
      }
    });
    if (this.MethodApproversTechExperts.length != 1) {
      this.MethodApproversTechExperts = this.MethodApproversTechExperts.filter((i: any) => i.RowId != rowId);
      for (var i = 0; i < this.MethodApproversTechExperts.length; i++) {
        this.MethodApproversTechExperts[i].RowId = i + 1;
      }
    }
  }

  MATechExpertChange(event, index) {
    this.MethodApproversTechExperts[index].Id = event.value.Id;
    this.MethodApproversTechExperts[index].Email = event.value.Email;
    this.MethodApproversTechExperts[index].Title = event.value.Title;
  }

  DeleteMRTechExpert(rowId: any) {
    let picked = [];
    this.users = [];
    this.MethodReviewersTechExperts.forEach(row => {
      if (picked.indexOf(row.Id) === -1) {
        picked.push(row.Id);
        this.users.push({ label: row.Id, value: row.Id });
      }
    });
    if (this.MethodReviewersTechExperts.length != 1) {
      this.MethodReviewersTechExperts = this.MethodReviewersTechExperts.filter((i: any) => i.RowId != rowId);
      for (var i = 0; i < this.MethodReviewersTechExperts.length; i++) {
        this.MethodReviewersTechExperts[i].RowId = i + 1;
      }
    }
  }

  MRTechExpertChange(event, index) {
    this.MethodReviewersTechExperts[index].Id = event.value.Id;
    this.MethodReviewersTechExperts[index].Email = event.value.Email;
    this.MethodReviewersTechExperts[index].Title = event.value.Title;
  }

  onUpload(event) {
    debugger;
    this.uploadedFiles = [];

    for(let file of event.files) {
        this.uploadedFiles.push(file);
        this.filename = file.name;
        this.filesize = file.size;
    }
    
    this.uploadDisplay = true;
  }

  UploadDoc() {
    const body3 = this.uploadedFiles[0];
    this.methodetailservice.onUpload(body3).then((response: SPHttpClientResponse): void => {
        this.uploadDisplay = false;
        this.messageService.clear();
        this.messageService.add({ severity: 'success', summary: '', detail: "Document saved successfully" });
      }, (error: any): void => {
        this.uploadDisplay = false;
        this.messageService.clear();
        this.messageService.add({ severity: 'warn', summary: '', detail: 'Document is not uploaded' });
    });
  }

  UploadCancel() {
    this.uploadedFiles[0] = null;
    this.uploadDisplay = false;
  }
}  







