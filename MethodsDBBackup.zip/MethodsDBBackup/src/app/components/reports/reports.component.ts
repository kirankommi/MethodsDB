import { Component, OnInit, Input } from '@angular/core';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { Teamadtls } from '../../models/ReportModel'
import { text } from '@angular/core/src/render3/instructions';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  @Input() context: WebPartContext;
  currentWebUrl: string = '';
  teamadtls: Teamadtls[];
  data: any;
  options: any;
  datatime:any;
  dataInventory: any;
  optiontime:any;
  optionsInventory: any;
  version:string[] = [];
  revisionTypes: number[] = [];
  tempRevisionTypes: number[] = [];
  newTypes: number[] = [];
  tempNewTypes: number[] = [];
  procedureTypes: number[] = [];
  tempProcedureTypes: number[] = [];
  qlmTypes: number[] = [];
  tempQlmTypes: number[] = [];
  methodNos: string[] = [];
  teamTitles: string[] = [];
  requestPeriod: number[] = [];
  draftPeriod: number[] = [];
  reviewPeriod: number[] = [];
  approvalPeriod: number[] = [];
  publishedPeriod: number[] = [];
  requestInvPeriod: number[] = [];
  draftInvPeriod: number[] = [];
  reviewInvPeriod: number[] = [];
  approvalInvPeriod: number[] = [];
  publishedInvPeriod: number[] = [];
  revisionChecked: boolean = true;
  newChecked: boolean = true;
  proceduresChecked: boolean = true;
  qlmChecked: boolean = true;

  constructor() { 
    
  }

   ngOnInit() {
    this.context = window["webPartContext"];
    this.currentWebUrl = this.context.pageContext.web.absoluteUrl;
    this.getTeams();
    this.getRequests();
  }

  getTeams(){
    let requestLibrary = 'lstTeamAdditionalDtls';
    let requestUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + requestLibrary + "'" + ')/items')
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON.value.length != 0) {
              for(let v = 0; v < responseJSON.value.length; v++){
                if(!this.version.includes(responseJSON.value[v].VersionNo) && responseJSON.value[v].VersionNo != null){
                  this.version.push(responseJSON.value[v].VersionNo);
                  this.revisionTypes.push(0);
                  this.newTypes.push(0);
                  this.procedureTypes.push(0);
                  this.qlmTypes.push(0);
                }
              }

              for(let i = 0; i < responseJSON.value.length; i++){
                for(let j = 0; j < this.version.length; j++){
                  if(this.version[j] == responseJSON.value[i].VersionNo){
                    if(responseJSON.value[i].MethodType == 'Revision'){
                      this.revisionTypes[j] = this.revisionTypes[j] + 1
                    }
                    if(responseJSON.value[i].MethodType == 'New'){
                      this.newTypes[j] = this.newTypes[j] + 1
                    }
                    if(responseJSON.value[i].MethodType == 'Procedures'){
                      this.procedureTypes[j] = this.procedureTypes[j] + 1
                    }
                    if(responseJSON.value[i].MethodType == 'QLM'){
                      this.qlmTypes[j] = this.qlmTypes[j] + 1
                    }
                  }
                }
              }

              this.tempRevisionTypes = this.revisionTypes;
              this.tempNewTypes = this.newTypes;
              this.tempProcedureTypes = this.procedureTypes;
              this.tempQlmTypes = this.qlmTypes;
              this.addDataUOPReport();
            }
          })
        }
      })
  }

  addDataUOPReport(){
    this.data = {
      labels: this.version,
      datasets: [
        {
          label:'Revision',
          backgroundColor: '#42A5F5',
          borderColor: '#1E88E5',
          data: this.revisionTypes
        },
        {
          label:'New',
          backgroundColor: 'orange',
          borderColor: '#1E88E5',
          data: this.newTypes
        },
        {
          label:'Procedures',
          backgroundColor: 'yellow',
          borderColor: '#1E88E5',
          data: this.procedureTypes
        },
        {
          label:'QLM',
          backgroundColor: 'violet',
          borderColor: '#1E88E5',
          data: this.qlmTypes
        },
      ]
    }

    this.options = {
      title: {
          display: true,
          text: 'NO. OF EACH TYPE PER YEAR',
          fontSize: 16,
          position: 'left'
      },
      legend: {
        position: 'bottom'
      },
      scales: {
        xAxes: [{
            stacked: true
        }],
        yAxes: [{
            stacked: true
        }]
      }
    }
  }
  
  getRequests(){
    let TeamList = 'lstTeamAdditionalDtls';
    let requestTeamUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + TeamList + "'" + ')/items')
    this.context.spHttpClient.get(requestTeamUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON.value.length != 0) {
              this.teamadtls = responseJSON.value;
              this.teamadtls.sort((a, b) => a.Title.localeCompare(b.Title));

              for(let v = 0; v < this.teamadtls.length; v++) {
                this.methodNos.push(this.teamadtls[v].MethodNo);
                this.teamTitles.push(this.teamadtls[v].Title);
              }

              let requestLibrary = 'lstMethodRequest';
              let requestUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + requestLibrary + "'" + ')/items')
              this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
              .then((response: SPHttpClientResponse) => {
                if (response.ok) {
                  response.json().then((responseJSON) => {
                    if (responseJSON.value.length != 0) {
                      
                      //Method Cycles
                      for(let j = 0; j < responseJSON.value.length; j++) {
                          if(this.teamTitles.includes(responseJSON.value[j].ID.toString())) {
                            this.requestPeriod.push(0);
                            this.draftPeriod.push(0);
                            this.reviewPeriod.push(0);
                            this.approvalPeriod.push(0);
                            this.publishedPeriod.push(0);
                          }
                      }

                      for(let i = 0; i < responseJSON.value.length; i++)  {
                        if(this.teamTitles.includes(responseJSON.value[i].ID.toString())) {
                          if(responseJSON.value[i].Date_Draft != null && responseJSON.value[i].Date_Draft != undefined){
                            this.requestPeriod[i] = this.requestPeriod[i] + this.monthDiff(new Date(responseJSON.value[i].Date_Requested), new Date(responseJSON.value[i].Date_Draft));
                          }
                          if(responseJSON.value[i].Date_Draft != null && responseJSON.value[i].Date_Review != null) {
                            this.draftPeriod[i] = this.draftPeriod[i] + this.monthDiff(new Date(responseJSON.value[i].Date_Draft), new Date(responseJSON.value[i].Date_Review));
                          }
                          if(responseJSON.value[i].Date_Review != null && responseJSON.value[i].Date_Approve != null) {
                            this.reviewPeriod[i] = this.reviewPeriod[i] + this.monthDiff(new Date(responseJSON.value[i].Date_Review), new Date(responseJSON.value[i].Date_Approve));
                          }
                          if(responseJSON.value[i].Date_Approve != null && responseJSON.value[i].Date_Publish != null) {
                            this.approvalPeriod[i] = this.approvalPeriod[i] + this.monthDiff(new Date(responseJSON.value[i].Date_Approve), new Date(responseJSON.value[i].Date_Publish));
                          }
                          if(responseJSON.value[i].Date_Publish != null && responseJSON.value[i].Date_TechReport != null) {
                            this.publishedPeriod[i] = this.publishedPeriod[i] + this.monthDiff(new Date(responseJSON.value[i].Date_Publish), new Date(responseJSON.value[i].Date_TechReport));
                          }
                        }
                      }

                      this.addDataToMethodCycleReport();

                      //Inventory
                      this.requestInvPeriod.push(0,0,0,0,0,0,0,0,0,0,0,0);
                      this.draftInvPeriod.push(0,0,0,0,0,0,0,0,0,0,0,0);
                      this.reviewInvPeriod.push(0,0,0,0,0,0,0,0,0,0,0,0);
                      this.approvalInvPeriod.push(0,0,0,0,0,0,0,0,0,0,0,0);
                      this.publishedInvPeriod.push(0,0,0,0,0,0,0,0,0,0,0,0);

                      for(let i = 0; i < responseJSON.value.length; i++){
                        
                      }

                      this.addDataToInventoryReport();
                    }
                  })
                }
              })
            }
          })
        }
      })

    
  }

  monthDiff(dateFrom, dateTo) {
    return dateTo.getMonth() - dateFrom.getMonth() + 
      (12 * (dateTo.getFullYear() - dateFrom.getFullYear()))
   }

  addDataToMethodCycleReport(){
    this.datatime = {
      labels: this.methodNos,
      datasets: [
          {
              label:'Requests',
              backgroundColor: '#ff531a',
              borderColor: '#1E88E5',
              data: this.requestPeriod,
          },
          {
            label:'Draft',
            backgroundColor: 'orange',
            borderColor: '#1E88E5',
            data: this.draftPeriod,
          },
          {
            label:'Review',
            backgroundColor: 'violet',
            borderColor: '#1E88E5',
            data: this.reviewPeriod,
          },
          {
            label:'Appr',
            backgroundColor: 'red',
            borderColor: '#1E88E5',
            data: this.approvalPeriod,
          },
          {
            label:'Published',
            backgroundColor: 'pink',
            borderColor: '#1E88E5',
            data: this.publishedPeriod,
          },
      ]
    }

    this.optiontime = {
      title: {
          display: true,
          text: 'ELAPSED TIME, MONTHS',
          fontSize: 16,
          position: 'left'
      },
      legend: {
        position: 'bottom'
      },
      scales: {
        xAxes: [{
            stacked: true
        }],
        yAxes: [{
            stacked: true
        }]
      }
      
    }
  }

  addDataToInventoryReport(){
    this.dataInventory = {
      labels: ['January','February','March','April','May','June','July','August','September','October','November','December'],
      datasets: [
          {
              label:'Requests',
              backgroundColor: '#ff531a',
              borderColor: '#1E88E5',
              data: this.requestInvPeriod,
          },
          {
            label:'Draft',
            backgroundColor: 'orange',
            borderColor: '#1E88E5',
            data: this.draftInvPeriod,
          },
          {
            label:'Review',
            backgroundColor: 'violet',
            borderColor: '#1E88E5',
            data: this.reviewInvPeriod,
          },
          {
            label:'Appr',
            backgroundColor: 'red',
            borderColor: '#1E88E5',
            data: this.approvalInvPeriod,
          },
          {
            label:'Published',
            backgroundColor: 'pink',
            borderColor: '#1E88E5',
            data: this.publishedInvPeriod,
          },
      ]
    }

    this.optionsInventory = {
      title: {
          display: true,
          text: 'DATE PUBLISHED',
          fontSize: 16,
          position: 'bottom'
      },
      scales: {
        xAxes: [{
            stacked: true
        }],
        yAxes: [{
            stacked: true
        }]
      }
      
    }
  }

  toggleRevision(event) {
    if (event) {
      this.revisionTypes = this.tempRevisionTypes;
      this.addDataUOPReport();
    }
    else if (!event) {
      this.revisionTypes = [];
      this.addDataUOPReport();
    }
  }

  toggleNew(event) {
    if (event) {
      this.newTypes = this.tempNewTypes;
      this.addDataUOPReport();
    }
    else if (!event) {
      this.newTypes = [];
      this.addDataUOPReport();
    }
  }

  toggleProcedures(event) {
    if (event) {
      this.procedureTypes = this.tempProcedureTypes;
      this.addDataUOPReport();
    }
    else if (!event) {
      this.procedureTypes = [];
      this.addDataUOPReport();
    }
  }

  toggleQLM(event) {
    if (event) {
      this.qlmTypes = this.tempQlmTypes;
      this.addDataUOPReport();
    }
    else if (!event) {
      this.qlmTypes = [];
      this.addDataUOPReport();
    }
  }
}
