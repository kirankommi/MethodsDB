/* tslint:disable */
require('./methodrequest.component.css');

/* tslint:enable */