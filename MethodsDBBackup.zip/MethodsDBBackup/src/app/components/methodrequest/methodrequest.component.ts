import { Component, OnInit, Input } from '@angular/core';
import { DashboardService } from '../../services/dashboard/dashboard.service';
import { IWebPartContext } from '@microsoft/sp-webpart-base';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { MethodService } from '../../services/method.service';
import { RequestTypes, RequestorModel, Lab_centers, PlantsAffected, SampleMatrix, Priorities, lstSource_of_Request } from '../../models/RequestorModel';
import { ActivatedRoute } from '@angular/router';
import { AlertMessage } from '../../services/alertmessage.service';
import { MessageService } from 'primeng/api';
import { PeoplePickerUser, PeoplePickerQuery, PeoplePickerUserEntityData } from '../../interfaces/people-picker-query';
import { AppComponent } from './../../app.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-methodrequest',
  templateUrl: './methodrequest.component.html',
  styleUrls: ['./methodrequest.component.scss'],
  providers: [DashboardService]
})

export class MethodrequestComponent implements OnInit {
  @Input() context: WebPartContext;
  public users: PeoplePickerUser[];
  public multipleUsers: PeoplePickerUser[];
  public BASE_PHOTO_URL = 'https://honeywellprod.sharepoint.com/_layouts/15/userphoto.aspx?size=S&accountname=';
  spuser: PeoplePickerUser;
  spusers: PeoplePickerUser[] = [];

  currentWebUrl: string = '';
  lists: Promise<any[]>;
  reqList: Promise<any[]>;
  lstRequestTypes: RequestTypes[];
  lstPriorities: Priorities[];
  requestor: RequestorModel = new RequestorModel();
  otherChecked = false;
  requestorSaved: string = "You have successfully inserted the request ";
  lstlabcenter: Lab_centers[];
  lstPlantsAffected: PlantsAffected[];
  lstSampleMatrix: SampleMatrix[];
  lstSourceofRequest: lstSource_of_Request[];
  selectedPlantsAffected: PlantsAffected[] = [];
  selectedSampleMatrix: SampleMatrix[] = [];
  selectedLabCenters: Lab_centers[] = []
  PlantsAffectedArray: number[] = [];
  SampleMatrixArray: number[] = [];
  LabCentersArray: number[] = [];
  sub: any;
  Id: string;
  methodRequest: RequestorModel;

  constructor(public service: DashboardService,
    public methodService: MethodService,
    private route: ActivatedRoute,
    private router: Router,
    private alertMessage: AlertMessage,
    private messageService: MessageService, private app: AppComponent) {

  }
  peoplePickerQuery: PeoplePickerQuery = {
    queryParams: {
      QueryString: '',
      MaximumEntitySuggestions: 10,
      AllowEmailAddressess: true,
      AllowOnlyEmailAddressess: false,
      PrinciplaSource: 15,
      PrinciplaType: 1,
      SharePointGroupId: 0
    }
  };
  filteredCountriesMultiple: any[];

  filterSPUserSingle(event) {
    this.filterSPUsers(event.query, 'single');
  }

  filterSPUserMultiple(event) {
    this.filterSPUsers(event.query, 'multiple');
  }
  onSelect(event) {
    console.log(event);
    this.requestor.Requester = event.DisplayText;
    this.requestor.RequestorEmail = event.EntityData.Email;
    this.requestor.Phone = event.EntityData.MobilePhone;
  }
  filterSPUsers(query, type) {
    this.peoplePickerQuery = Object.assign({
      queryParams: {
        QueryString: query,
        MaximumEntitySuggestions: 10,
        AllowEmailAddresses: true,
        AllowOnlyEmailAddresses: false,
        PrincipalSource: 15,
        PrincipalType: 1,
        SharePointGroupID: 0
      }
    });

    this.service.getUserSuggestions(this.context, this.peoplePickerQuery)
      .subscribe((result: any) => {
        if (type === 'single') {
          this.users = [];
          const allUsers: PeoplePickerUser[] = JSON.parse(
            result.d.ClientPeoplePickerSearchUser
          );
          allUsers.forEach(user => {
            this.users = [...this.users, user];
          });
        } else {
          this.multipleUsers = [];
          const allUsers: PeoplePickerUser[] = JSON.parse(
            result.d.ClientPeoplePickerSearchUser
          );
          allUsers.forEach(user => {
            this.multipleUsers = [...this.multipleUsers, user];
          });
        }
      });
  }
  ngOnInit() {
    this.context = window["webPartContext"];
    if (!this.context) {
      console.error('Please provide the context!');
      return;
    }
    // this.getUserGroups();
    this.currentWebUrl = this.context.pageContext.web.absoluteUrl;
    this.lists = this.context.spHttpClient.get(`${this.context.pageContext.web.absoluteUrl}/_api/web/lists`, SPHttpClient.configurations.v1)
      .then(res => res.json())
      .then(res => res.value)
      .catch(err => console.log(err));

    this.getListItems();
    this.sub = this.route.params.subscribe(params => {
      this.Id = params['Id'];
      if (this.Id != undefined || this.Id != null) {
        this.getRequstbyId(this.Id);
      }
      else {
        this.users = [];
        this.multipleUsers = [];
        let people: PeoplePickerUser;
        let data: PeoplePickerUserEntityData;
        data = {
          Email: this.context.pageContext.user.email, Title: this.context.pageContext.user.displayName, Department: "Test", MobilePhone: null,
          IsAlSecIdPresent: false, ObjectId: null
        };
        people = {
          DisplayText: this.context.pageContext.user.displayName, EntityData: data, Key: "1", Description: this.context.pageContext.user.displayName,
          EntityType: null, ProvideDisplayName: this.context.pageContext.user.displayName, ProviderName: null, IsResolved: true, MultipleMatches: null
        };
        this.spusers.push(people);
        this.spuser = people;
        this.requestor.Requester = this.spuser.DisplayText;
        this.requestor.RequestorEmail = this.spuser.EntityData.Email;
        this.requestor.Phone = this.spuser.EntityData.MobilePhone;
        this.requestor.Date_Requested = new Date();
      }
    });
    this.messageService.clear();
  }
  
  getRequstbyId(Id: string) {
    let requestLibrary = 'lstMethodRequest';
    let requestUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + requestLibrary + "'" + ')/items(' + Id + ')')
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null) {
              this.methodRequest = responseJSON;
              debugger;
              // this.multipleUsers = [];
              let user: PeoplePickerUser;
              let data: PeoplePickerUserEntityData;
              data = {
                Email: this.methodRequest.RequestorEmail, Title: this.methodRequest.Requester, Department: "", MobilePhone: this.methodRequest.Phone,
                IsAlSecIdPresent: false, ObjectId: null
              };
              user = {
                DisplayText: this.methodRequest.Requester, EntityData: data, Key: "1", Description: this.methodRequest.Requester,
                EntityType: null, ProvideDisplayName: this.methodRequest.Requester, ProviderName: null, IsResolved: true, MultipleMatches: null
              };
              // this.spusers.push(people);
              this.spuser = user;
              this.requestor.Id = this.methodRequest.Id;
              this.requestor.Date_Requested = new Date(this.methodRequest.Date_Requested);
              this.requestor.Requester = this.methodRequest.Requester;
              this.requestor.Phone = this.spuser.EntityData.MobilePhone;
              this.requestor.RequestorEmail = this.spuser.EntityData.Email;
              this.requestor.SchedA_934_Eng= this.methodRequest.SchedA_934_Eng;
              this.requestor.Tech_Service = this.methodRequest.Tech_Service;
              this.requestor.Manufacturing = this.methodRequest.Manufacturing;
              this.requestor.Instrumentation = this.methodRequest.Instrumentation;
              this.requestor.Training = this.methodRequest.Training;
              this.requestor.Others = this.methodRequest.Others;
              this.otherChecked = this.methodRequest.Others;
              this.requestor.OthersData = this.methodRequest.OthersData;
              //this.requestor.LabCentersId = this.methodRequest.LabCentersId;
              //this.requestor.PlantsAffectedId = this.methodRequest.PlantsAffectedId;
              this.requestor.Request_TypeId = this.methodRequest.Request_TypeId;
              this.requestor.PriorityId = this.methodRequest.PriorityId;
              this.requestor.Source_of_RequestId = this.methodRequest.Source_of_RequestId;

              this.selectedLabCenters = [];
              for (let i = 0; i < this.methodRequest.LabCentersId.length; i++) {
                this.selectedLabCenters.push({ Id: Number(this.methodRequest.LabCentersId[i]), Title: '' });
              }

              this.selectedPlantsAffected = [];
              for (let i = 0; i < this.methodRequest.PlantsAffectedId.length; i++) {
                this.selectedPlantsAffected.push({ Id: Number(this.methodRequest.PlantsAffectedId[i]), Title: '' });
              }

              this.selectedSampleMatrix = [];
              for (let i = 0; i < this.methodRequest.Sample_MatrixId.length; i++) {
                this.selectedSampleMatrix.push({ Id: Number(this.methodRequest.Sample_MatrixId[i]), Title: '' });
              }

              this.requestor.Project_Activity = this.methodRequest.Project_Activity;
              this.requestor.Cost_Center = this.methodRequest.Cost_Center;
              this.requestor.Title = this.methodRequest.Title;
              this.requestor.Problem_Statement = this.methodRequest.Problem_Statement;
              this.requestor.Change_Requested = this.methodRequest.Change_Requested;
              this.requestor.Business_Need = this.methodRequest.Business_Need;
              this.requestor.Additional_Info = this.methodRequest.Additional_Info;
              this.requestor.Safety_concerns = this.methodRequest.Safety_concerns;
              this.requestor.Component_Limit_of_Detection = this.methodRequest.Component_Limit_of_Detection;
              this.requestor.Matrix_StreamComposition = this.methodRequest.Matrix_StreamComposition;
              this.requestor.Matrix_StreamConcentrationRange = this.methodRequest.Matrix_StreamConcentrationRange;
            }
          });
        }
      });
  }

  getListItems() {
    let library = 'lstRequestType';
    let currentWebUrl = this.context.pageContext.web.absoluteUrl;
    let requestUrl = currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + library + "'" + ')/items')
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstRequestTypes = responseJSON.value;
              this.requestor.Request_TypeId = "";
            }
          });
        }
      });

    let Priority = 'lstPriority';
    this.context.spHttpClient.get(currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + Priority + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstPriorities = responseJSON.value;
              this.requestor.PriorityId = "";
            }
          });
        }
      });

    let PlantsAffected = 'lstPlantsAffected';
    this.context.spHttpClient.get(currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + PlantsAffected + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstPlantsAffected = responseJSON.value;
              this.lstPlantsAffected.sort((a, b) => a.Title.localeCompare(b.Title));
            }
          });
        }
      });

    let SampleMatrix = 'lstSampleMatrix';
    this.context.spHttpClient.get(currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + SampleMatrix + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstSampleMatrix = responseJSON.value;
            }
          });
        }
      });

    let Source_of_Request = 'lstSource_of_Request';
    this.context.spHttpClient.get(currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + Source_of_Request + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstSourceofRequest = responseJSON.value;
              this.requestor.Source_of_RequestId = "";
            }
          });
        }
      });

    let LabCenters = 'lstLabCenter';
    this.context.spHttpClient.get(currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + LabCenters + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstlabcenter = responseJSON.value;
              this.lstlabcenter.sort((a, b) => a.Title.localeCompare(b.Title));
            }
          });
        }
      });
  }

  Reset() {
    this.users = [];
    this.multipleUsers = [];
    let people: PeoplePickerUser;
    let data: PeoplePickerUserEntityData;
    data = {
      Email: this.context.pageContext.user.email, Title: this.context.pageContext.user.displayName, Department: "Test", MobilePhone: null,
      IsAlSecIdPresent: false, ObjectId: null
    };
    people = {
      DisplayText: this.context.pageContext.user.displayName, EntityData: data, Key: "1", Description: this.context.pageContext.user.displayName,
      EntityType: null, ProvideDisplayName: this.context.pageContext.user.displayName, ProviderName: null, IsResolved: true, MultipleMatches: null
    };
    this.spusers.push(people);
    this.spuser = people;

    this.requestor.Date_Requested = new Date();
    //this.spuser.EntityData.Title = this.context.pageContext.user.displayName;
    this.requestor.Phone = null;
    this.requestor.RequestorEmail = this.context.pageContext.user.email;
    this.requestor.SchedA_934_Eng= null;
    this.requestor.Tech_Service = null;
    this.requestor.Manufacturing = null;
    this.requestor.Instrumentation = null;
    this.requestor.Training = null;
    this.requestor.Others = false;
    this.otherChecked = false;
    this.requestor.OthersData = "";
    this.selectedLabCenters = null;
    this.selectedPlantsAffected = null;
    this.requestor.Request_TypeId = "";
    this.requestor.PriorityId = "";
    this.requestor.Source_of_RequestId = "";
    this.selectedSampleMatrix = null;
    this.requestor.Project_Activity = "";
    this.requestor.Cost_Center = "";
    this.requestor.Title = "";
    this.requestor.Problem_Statement = "";
    this.requestor.Change_Requested = "";
    this.requestor.Business_Need = "";
    this.requestor.Additional_Info = "";
    this.requestor.Safety_concerns = "";
    this.requestor.Component_Limit_of_Detection = "";
    this.requestor.Matrix_StreamComposition = "";
    this.requestor.Matrix_StreamConcentrationRange = "";
  }

  Save() {
    if (this.isDataValid()) {
      if (this.selectedPlantsAffected.length != undefined) {
        for (let i = 0; i < this.selectedPlantsAffected.length; i++) {
          this.PlantsAffectedArray.push(this.selectedPlantsAffected[i].Id)
        }
      }

      if (this.selectedSampleMatrix.length != undefined) {
        for (let i = 0; i < this.selectedSampleMatrix.length; i++) {
          this.SampleMatrixArray.push(this.selectedSampleMatrix[i].Id)
        }
      }

      if (this.selectedLabCenters.length != undefined) {
        for (let i = 0; i < this.selectedLabCenters.length; i++) {
          this.LabCentersArray.push(this.selectedLabCenters[i].Id)
        }
      }

      if (this.requestor.Id != null || this.requestor.Id != undefined) {
        this.methodService.updateItem(
          this.requestor.Id,
          this.requestor.Title,
          this.requestor.Date_Requested,
          this.requestor.Requester,
          this.requestor.Phone,
          this.requestor.RequestorEmail,
          this.requestor.SchedA_934_Eng,
          this.requestor.Tech_Service,
          this.requestor.Manufacturing,
          this.requestor.Instrumentation,
          this.requestor.Training,
          this.requestor.Others,
          this.requestor.OthersData,
          this.LabCentersArray,
          this.PlantsAffectedArray,
          this.requestor.Request_TypeId ? undefined : null,
          this.requestor.PriorityId,
          this.requestor.Source_of_RequestId,
          this.SampleMatrixArray,
          this.requestor.Project_Activity,
          this.requestor.Cost_Center,
          this.requestor.Problem_Statement,
          this.requestor.Change_Requested,
          this.requestor.Business_Need,
          this.requestor.Additional_Info,
          this.requestor.Safety_concerns,
          this.requestor.Component_Limit_of_Detection,
          this.requestor.Matrix_StreamComposition,
          this.requestor.Matrix_StreamConcentrationRange,
          this.requestor.StatusId).then((res) => {
            this.messageService.clear();
            this.messageService.add({ severity: 'success', summary: '', detail: this.requestorSaved });
          });
      }
      else {
        this.methodService.createItem(
          this.requestor.Id,
          this.requestor.Title,
          this.requestor.Date_Requested,
          this.requestor.Requester,
          this.requestor.Phone,
          this.requestor.RequestorEmail,
          this.requestor.SchedA_934_Eng,
          this.requestor.Tech_Service,
          this.requestor.Manufacturing,
          this.requestor.Instrumentation,
          this.requestor.Training,
          this.requestor.Others,
          this.requestor.OthersData,
          this.LabCentersArray,
          this.PlantsAffectedArray,
          this.requestor.Request_TypeId,
          this.requestor.PriorityId,
          this.requestor.Source_of_RequestId,
          this.SampleMatrixArray,
          this.requestor.Project_Activity,
          this.requestor.Cost_Center,
          this.requestor.Problem_Statement,
          this.requestor.Change_Requested,
          this.requestor.Business_Need,
          this.requestor.Additional_Info,
          this.requestor.Safety_concerns,
          this.requestor.Component_Limit_of_Detection,
          this.requestor.Matrix_StreamComposition,
          this.requestor.Matrix_StreamConcentrationRange,
          this.requestor.StatusId).then((res) => {
            this.router.navigateByUrl('/dashboard');
            this.messageService.clear();
            this.messageService.add({ severity: 'success', summary: '', detail: this.requestorSaved + this.requestor.Title});
          });
      }
    }
    else {
      this.messageService.clear();
      this.messageService.add({ severity: 'warn', summary: '', detail: 'Please fill in all the required fields' });
    }
  }

  isDataValid() {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    let req = this.requestor.RequestorEmail;
    if (this.selectedSampleMatrix == null || this.selectedSampleMatrix.length == 0) {
      return false;
    }
    if (this.requestor.Project_Activity == null && this.requestor.Cost_Center == null) {
      return false;
    }
    if (!this.requestor.SchedA_934_Eng &&
      !this.requestor.Tech_Service &&
      !this.requestor.Manufacturing &&
      !this.requestor.Instrumentation &&
      !this.requestor.Training &&
      !this.requestor.Others) {
      return false;
    }
    else if (
      this.spuser == null ||
      this.requestor.RequestorEmail == null ||
      this.requestor.Phone == null ||
      this.requestor.Phone == null ||
      this.requestor.Date_Requested == null ||
      this.requestor.Request_TypeId == null ||
      this.requestor.Request_TypeId == "" ||
      this.requestor.PriorityId == null ||
      this.requestor.PriorityId == "" ||
      this.requestor.Title == null ||
      this.requestor.Problem_Statement == null ||
      this.requestor.Business_Need == null ||
      this.requestor.Component_Limit_of_Detection == null ||
      this.requestor.Matrix_StreamConcentrationRange == null ||
      this.requestor.Matrix_StreamComposition == null ||
      !req.match(mailformat)
    ) {
      return false;
    }
    return true;
  }

  toggleOther(event) {
    if (event) {
      this.otherChecked = true;
    }
    else if (!event) {
      this.otherChecked = false;
    }
  }

  
}
