export enum MenuType {
    BRAND,
    LEFT,
    RIGHT
}

export interface ChildRoute {
    action: string;
    title: string;
    menuType: MenuType;
}

export interface RouteInfo {
    action: string;
    title: string;
    menuType: MenuType;
    routes: ChildRoute[];
}

export class MenuModel {
    //Name: string;
    //Link: string
    title: string
    action?: string;
    menuOrder: number;
    //FunctionCode: string;
    //FunctionDescription: string;
    //ParentFunctionCode: string;
    //FunctionOrder: string;
    //PrivilegeName: string;
    //IsReadOnly: boolean;
    menuType?: MenuType;
    subMenu?: MenuModel[] = [];
}

