/* tslint:disable */
require('./dashboard.component.css');

/* tslint:enable */