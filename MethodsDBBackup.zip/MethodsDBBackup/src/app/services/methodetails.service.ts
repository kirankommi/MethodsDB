import { Injectable, Input } from '@angular/core';
import { from } from 'rxjs/observable/from';
import { HttpClient,HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise'
import {IRequestDigest,IListItemEntityType} from '../app.common';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient, SPHttpClientResponse} from '@microsoft/sp-http';
import{MethodNotes} from'../models/MethodDetailModel';

@Injectable()
export class Methodetailservice {
  listItemEntityTypeName: string = '';
  formDigestValue: string = '';
  public currentItem: any;
  methodNotes: MethodNotes[];
  //url: string = 'https://honeywellprod.sharepoint.com/teams/MethodsDBD';
  url: string = 'https://honeywellprod.sharepoint.com/teams/MethodsDBST';
  listName = 'lstMethodNotes';
  TeamList = 'lstTeamAdditionalDtls';
  uploadDocs = 'MethodsDocuments'

  constructor(private http: HttpClient) {
    this.listName='lstMethodNotes';
  }

  public SaveNotes(title: string,header:Date,description:string, Indicator:string): Promise<any> {
    let promise = new Promise((resolve, reject) => {
      this.getListItemEntityTypeName(this.listName)
        .then((res) => {
          return this.getRequestDigest();
        })
        .then((res) => {
          let headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
          headers = headers.set('Content-type', 'application/json;odata=verbose');
          headers = headers.set('X-RequestDigest', this.formDigestValue);
          const requestOptions = {
            headers: headers
          };
          const body: string = JSON.stringify({
            '__metadata': {
              'type': this.listItemEntityTypeName
            },
            'Title': title,
            'Header':header,
            'Description':description,
            'Indicator':Indicator
          });
          this.http.post(this.url+'/_api/web/lists/getbytitle('+"'"+this.listName+"'"+')/items',
          body, requestOptions).toPromise().then(res => { resolve(); });
          
        });
    });
    return promise;
  }

  public SaveTeamDetails(body: any): Promise<any> {
    let promise = new Promise((resolve, reject) => {

      this.getListItemEntityTypeName(this.TeamList)
        .then((res) => {
          return this.getRequestDigest();
        })
        .then((res) => {
          let headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
          headers = headers.set('Content-type', 'application/json;odata=verbose');
          headers = headers.set('X-RequestDigest', this.formDigestValue);
          const requestOptions = {
            headers: headers
          };
          this.http.post(this.url+'/_api/web/lists/getbytitle('+"'"+this.TeamList+"'"+')/items',
          body, requestOptions).toPromise().then(res => { resolve(); });
          
        });
    });
    return promise;
  }

  public onUpload(body: any): Promise<any> {
    let filename = 'test';
    let promise = new Promise((resolve, reject) => {

      this.getListItemEntityTypeName(this.uploadDocs)
        .then((res) => {
          return this.getRequestDigest();
        })
        .then((res) => {
          let headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
          headers = headers.set('Content-type', 'application/json;odata=verbose');
          headers = headers.set('X-RequestDigest', this.formDigestValue);
          const requestOptions = {
            headers: headers
          };
          debugger;
          this.http.post(this.url+'/_api/web/GetFolderByServerRelativeUrl('+"'"+this.uploadDocs+"'"+')/Files/Add(url=test.docx, overwrite=true)',
          //this.http.post(this.url+'/_api/web/lists/getbytitle('+"'"+this.uploadDocs+"'"+')/items(146)/Attachments/add(FileName=test.docx)',
          body, requestOptions).toPromise().then(res => { resolve(); });
        });
    });
    return promise;
  }
  
   private getRequestDigest(): Promise<any> {
    let promise = new Promise((resolve, reject) => {
      const headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
      const requestOptions = {headers: headers};
      this.http.post(this.url + '/_api/contextinfo', '', requestOptions).toPromise().then((res: IRequestDigest) => { this.formDigestValue = res.FormDigestValue; resolve(); });
    });
    return promise;
  }

  public getListItemEntityTypeName(listname: string): Promise<any> {
    let promise = new Promise((resolve, reject) => {
      const headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
      const requestOptions = {headers: headers};
      this.http.get(this.url+'/_api/web/lists/getbytitle('+"'"+listname+"'"+')?$select=ListItemEntityTypeFullName', requestOptions
      ).toPromise().then((res: IListItemEntityType) => { console.log(res);this.listItemEntityTypeName = res.ListItemEntityTypeFullName; resolve(); });
    });
    return promise;
  }

}
