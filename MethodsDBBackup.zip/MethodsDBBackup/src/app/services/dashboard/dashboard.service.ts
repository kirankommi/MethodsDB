import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { PageContext } from '@microsoft/sp-page-context';
import {
  SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions
} from '@microsoft/sp-http';
import { environment } from "../../../environments/environment";
import { FormDigestResponse, PeoplePickerQuery } from "../../interfaces/people-picker-query";
import { Observable } from "rxjs";
import { mergeMap } from "rxjs/operators";
import { HttpClient, HttpHeaders } from "@angular/common/http";

const PEOPLE_PICKER_URL =
  '_api/SP.UI.ApplicationPages.ClientPeoplePickerWebServiceInterface.ClientPeoplePickerSearchUser';



export class DashboardService {
  constructor(private http: HttpClient) { }
  getListData(context: any, listName: string): Promise<any> {
    return context.spHttpClient.get(context.pageContext.web.absoluteUrl + '/_api/web/lists/GetByTitle(' + "'" + listName + "'" + ')/Items', SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        // console.log(response);
        return response.json();
      });
  }
  public getUserSuggestions(context: any, query: PeoplePickerQuery): Observable<any> {
    return this.http.post(`${environment.web}/_api/contextinfo`, '').pipe(
      mergeMap((xRequest: FormDigestResponse) => {
        const digest = xRequest.FormDigestValue;
        const headers = new HttpHeaders({
          accept: 'application/json;odata=verbose',
          'X-RequestDigest': digest
        });
        const httpOptions = {
          headers: headers
        };
        return this.http.post(
          `${environment.web}${PEOPLE_PICKER_URL}`,
          query,
          httpOptions
        );
      })
    );
  }
}
