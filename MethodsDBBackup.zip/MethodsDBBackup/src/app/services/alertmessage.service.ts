import { Injectable } from '@angular/core';

import { Message } from 'primeng/primeng';
import { AppErrorMessages } from '../shared/AppErrorMessages';
import { AppSuccessMessages } from '../Shared/AppSuccessMessages';
import { AppWarningMessages } from '../Shared/AppWarningMessages';

@Injectable()
export class AlertMessage {
    Msgs: any[] = [];
    constructor() { }

    displayMultipleMessage(msg: Message) {  
       
        msg.life = 10000; 
        this.Msgs.push(msg);
    }

    displayMessage(msg: Message) {   
        //Constants.Msgs = [];            
        msg.life = 10000;       
        //msg.sticky = true;
        this.Msgs.push(msg)
    }
    displayErrorMessage(id: string) { 
        let msg: Message = {};
        var appErrorMessage = new AppErrorMessages();
        var message = appErrorMessage.getErrorMessage(id)
        if (message) { 
            msg.detail = message.Details;
            msg.summary = message.Title;
            msg.closable = true;
            msg.life = 10000;           
            this.displayMessage(msg);
        }
    }
    displayWarningMessage(id:string)
    {
        let msg: Message = {};
        var appMessage = new AppWarningMessages();
        var message = appMessage.getWarningMessage(id)
        if (message) {
            msg.detail = message.Details;
            msg.summary = message.Title;
            msg.closable = true;
            msg.life = 10000;
            this.displayMessage(msg);
        }
    }
    displaySuccessMessage(id:string)
    {
        let msg: Message = {};
        var appMessage = new AppSuccessMessages();
        var message = appMessage.getSuccessMessage(id)
        if (message) {
            msg.detail = message.Details;
            msg.summary = message.Title;
            msg.closable = true;
            msg.life = 10000;
            //msg.sticky = true;
            this.displayMessage(msg);
        }
    }
    clearMsgs()
    {
        
    }
    
}
