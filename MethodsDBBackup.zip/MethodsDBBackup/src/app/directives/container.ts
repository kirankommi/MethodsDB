﻿import { Component, OnInit, Input } from '@angular/core';
import { Message } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    selector: 'fdms-html',
    templateUrl: 'container.html'
})

export class ContainerDirective {

}
