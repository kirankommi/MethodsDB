﻿import { Component, OnInit, Input } from '@angular/core';
import { Message } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    selector: 'fdms-body',
    templateUrl: 'body.html'
})

export class BodyDirective {

}
