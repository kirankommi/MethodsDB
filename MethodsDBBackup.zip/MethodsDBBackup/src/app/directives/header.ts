import { Component, OnInit, Input } from '@angular/core';
import { Message } from 'primeng/primeng';

@Component({
    //moduleId: module.id,
    selector: 'fdms-head',
    templateUrl: 'header.html'
})

export class HeaderDirective implements OnInit {
    @Input() title: string;
    @Input() userName: string;
    @Input() userEmail: string;
    @Input() menuData: any;
    _toggleSideMenu: boolean = false;
    signedUserName: string;
    signedUserInitial: string;

    IsUnauthorizedAccess: boolean = true;

    constructor() {
    }

    toggleSideMenu() {
        if (this._toggleSideMenu) {
            document.getElementById('fdms-container').style.marginLeft = '80px';
        }
        else {
            document.getElementById('fdms-container').style.marginLeft = '0px';
        }
        this._toggleSideMenu = !this._toggleSideMenu;

        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 1000);
    }
    ngOnInit() {      
       
    }
}
