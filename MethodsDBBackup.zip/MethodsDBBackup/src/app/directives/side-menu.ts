import { Component, OnInit, Input } from '@angular/core';
import { trigger, state, animate, transition, style } from '@angular/animations';
import { Router, NavigationEnd } from '@angular/router';

import { Message, TreeModule, TreeNode } from 'primeng/primeng';
//import { DashboardService } from '../Services/dashboard.service';
import { MenuType, MenuModel } from '../Components/NavBar/navbar.metadata';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { AppServiceService } from '../shared/app-service.service';
//declare var $: any;

@Component({
    selector: 'side-menu',
    templateUrl: 'side-menu.html',
    animations: [
        trigger('toggleState', [
            state('false', style({ maxHeight: '44px' })),
            state('true', style({ maxHeight: '400px' })),
            transition('* => *', animate('300ms')),
        ]),
        trigger('toggleCaret', [
            state('true', style({ maxHeight: '44px' })),
            state('false', style({ maxHeight: '400px' })),
            transition('* => *', animate('300ms')),
        ])
    ],
    host: {
        '(window:resize)': 'onResize($event)'
    },
    providers: [AppServiceService]
})

export class SideMenuDirective implements OnInit {
    public BASE_PHOTO_URL= 'https://honeywellprod.sharepoint.com/_layouts/15/userphoto.aspx?size=S&accountname=';
    @Input() menuData: any;
    @Input() context: WebPartContext;
    userEmail: string;
    files: TreeNode[];
    selectedMenu: string;
    signedUser: string;
    signedUserName: string;
    signedUserInitial: string;
    IsMethodCoordinator: boolean = false;
    IsMethodRequestor: boolean = false;
    toggledMenu: string[] = [];
    routes: MenuModel[] = [];
    public brandMenu: MenuModel;

    //Added later by chirag
    IsUnauthorizedAccess: boolean = false;

    constructor(private router: Router, private appService: AppServiceService ) { 
        this.routes = [
            {
                title: "test",
                action: "test",
                menuOrder: 1,
                menuType: null,
            }
        ];
    }

    ngOnInit() {
        //this.files = this.dashboardService.getFiles();
        this.context=window["webPartContext"];
        this.userEmail=this.context.pageContext.user.email;
        this.GetUserData();
        let userGroups : any;
        userGroups = this.appService.getFromLocal('userGroups');
        this.IsMethodCoordinator = userGroups.includes('MethodCoOrdinators');
        this.IsMethodRequestor = userGroups.includes('Requestors');
    }


    ngAfterViewInit() {
        this.router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                this.selectedMenu = event.url.replace("/", "");
                //this.selectedMenu = (this.selectedMenu && this.selectedMenu.includes('SelectFeedStep')) ? this.selectedMenu = 'SelectFeedStep' : this.selectedMenu;                
                // if (this.selectedMenu == "User" || this.selectedMenu == "Role" || this.selectedMenu == "RoleMenu" || this.selectedMenu == "UOM" || this.selectedMenu == "LimsAnalysisMethod" || this.selectedMenu == "LimsComponent" || this.selectedMenu == "CustomizeLandingPage") {
                if (this.isInManageMenuList(this.selectedMenu)) {
                    this.expandMenu('MANAGE');
                }
                if (this.selectedMenu == "SelectFeedStep" || this.selectedMenu == "Crude/Create" || this.selectedMenu == "SelectFeedStep/createfeed") {
                    this.expandMenu('FEED CREATION');
                }
                if (this.selectedMenu == "automap/map/component") {
                    this.selectedMenu = "automap/map/operation";
                }
            }
        });
        this.adjustMenuScroll();
    }
    onResize(event: any) {
        this.adjustMenuScroll();
    }

    isMenuToggled(_menu: string) {
        if (_menu == null) return false;
        return this.toggledMenu.indexOf(_menu) > -1;
    }


    adjustMenuScroll() {
        //$($("fdms-side-menu  .nav.level-1.score-component")[0]).slimScroll({
        //    position: 'left',
        //    height: (window.innerHeight - 113) + 'px',
        //    railVisible: false,
        //    alwaysVisible: false
        //});
    }


    selectMenu(_menu: string) {
        this.selectedMenu = _menu;
    }

    expandMenu(_menu: string) {
        if (this.toggledMenu.indexOf(_menu) < 0)
            this.toggledMenu.push(_menu);
    }

    expandCollapseMenu(_menu: string) {
        if (this.toggledMenu.indexOf(_menu) > -1)
            this.toggledMenu.splice(this.toggledMenu.indexOf(_menu), 1);
        else
            this.toggledMenu.push(_menu);
    }


    titleCase(input: string): string {
        
            return input;
        
    }


    GetUserData() {

        this.brandMenu = this.routes.filter((menuItem: any) => menuItem.menuType === MenuType.BRAND)[0];

        this.appService.getUserGroups(this.context);
    }


    generateMenu(menu: MenuModel[]) {

        for (let item of menu) {
            this.routes.push(item);
        }
    }
    getMenuImage(_title: string) {
        switch (_title) {
            case "PROJECT":
                return "assets/Images/Project.svg";
            case "CATALYST":
                return "assets/Images/Catalyst.svg";
            case "MANAGE":
                return "assets/Images/Manage.svg";
            case "FEED":
                return "assets/Images/Feed_Creation_icon_unselected.svg";
            case "EXPERIMENT":
                return "assets/Images/Experiment.svg";
            case "MINIS QUEUE":
                return "assets/Images/Minis_Active.svg";
            default:
                return "assets/Images//Advanced_Search_icon_unselect.svg";
        }
    }
    getManageMenu() {
        let manageMenu: any = this.routes.filter((menuItem: any) => menuItem.action == "Manage");
        if (manageMenu.length > 0 && manageMenu[0].subMenu.length > 0) {
            return manageMenu[0].subMenu;
        } else {
            return [];
        }
    }

    isInManageMenuList(menu: string) {
        const list = ["User", "Role", "RoleMenu", "UOM",
            "LimsAnalysisMethod", "LimsComponent", "CustomizeLandingPage",
            "automap/map/operation", "automap/map/component"];
        return list.indexOf(menu) >= 0;
    }
}
