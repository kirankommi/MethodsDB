import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {MethodrequestComponent} from './components/methodrequest/methodrequest.component'
import {DashboardComponent} from './components/dashboard/dashboard.component';
import {UserComponent} from './components/user/user.component'
import {MethodDetailsComponent} from './components/method-details/method-details.component';
import{ReportsComponent} from './components/reports/reports.component';


const routes: Routes = [
  { path: '', redirectTo: '/', pathMatch: 'full' },
  { path: 'request', component: MethodrequestComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'user', component: UserComponent },
  { path: 'methodetails/:Id', component: MethodDetailsComponent},
  { path: 'report', component: ReportsComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)], 
  exports: [RouterModule] 
})
export class AppRoutingModule { }

