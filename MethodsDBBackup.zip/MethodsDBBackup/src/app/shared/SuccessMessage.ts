﻿
export class SuccessMessage {
    public Id: string;
    public Title: string;
    public Details: string;
    public Error: any;
}