﻿import { WarningMessage } from './WarningMessage';
export class AppWarningMessages {
    WarningMessages: WarningMessage[] = [{ Id: "InvalidId", Title: "", Details: "Invalid Id Input.", Error: null },
        { Id: "DuplicateLimsSample", Title: '', Details: 'Duplicate LIMS Sample ID', Error: null },
        { Id: "AdvLIMSSearchMaximumCondition", Title: '', Details: 'Maximum 3 analysis method names can be selected and searched.', Error: null },
        { Id: "AdvLIMSSearchDuplicateMethodSelection", Title: '', Details: 'Selected Standard Method/Operation is already in the search list, please select a different one.', Error: null },           
        // { Id: "InvalidTestStartTime", Title: "Save Test Information", Details: "Please Enter a valid Start Time", Error: null },	
        // { Id: "InvalidTestEndTime", Title: "Save Test Information", Details: "Please Enter a valid End Time", Error: null },	
        // { Id: "InvalidTestStartEndTime", Title: "Save Test Information", Details: "Start Time is Greater Than End Time", Error: null },	
    ];

    public getWarningMessage(id: string) 
    {
        if (this.WarningMessages && this.WarningMessages.length>0)
        {
            var msg = this.WarningMessages.filter(x => x.Id == id)[0];
            if (msg)
            {
                return msg;
            }
            else
            {
                return new WarningMessage();
            }

        }

    }
}