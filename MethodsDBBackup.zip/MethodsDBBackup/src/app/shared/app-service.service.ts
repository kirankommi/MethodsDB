import { Injectable, Inject } from '@angular/core';
import { AppComponent } from '../app.component';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { LOCAL_STORAGE, WebStorageService } from 'angular-webstorage-service';

@Injectable()
export class AppServiceService {
  public data: any = []
  public context: any;
  constructor( @Inject(LOCAL_STORAGE) private storage: WebStorageService) { }
  async getUserGroups(context: any) {
    let userId = context.pageContext.legacyPageContext.userId;
    let siteGroupsData = await context.spHttpClient.get(context.pageContext.site.absoluteUrl + "/_api/web/currentuser/groups", SPHttpClient.configurations.v1);
    let userGroups: any = [];
    siteGroupsData.json().then(d => {
      var siteGroups = d.value;
      siteGroups.forEach(siteGroup => {
        userGroups.push(siteGroup.Title);
      });
      this.saveInLocal('userGroups', userGroups);
    });
    // this.app.getFromLocal('userGroups');
  }
  saveInLocal(key, val): void {
    this.storage.set(key, val);
    this.data[key] = this.storage.get(key);
    console.log(this.data);
  }
  getFromLocal(key): any {
    this.data[key] = this.storage.get(key);
    console.log(this.data);
    return this.data[key];
  }
}
