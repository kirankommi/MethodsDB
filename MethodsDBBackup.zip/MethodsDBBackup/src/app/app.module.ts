import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule, ApplicationRef } from '@angular/core';
import { APP_BASE_HREF } from '@angular/common';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { MethodrequestComponent } from './components/methodrequest/methodrequest.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UserComponent } from './components/user/user.component';
import { FormsModule } from '@angular/forms';
import { MultiSelectModule } from 'primeng/primeng';
import {MethodService} from './services/method.service';
import {Methodetailservice} from './services/methodetails.service';
import { HttpClientModule  } from "@angular/common/http";
import {CalendarModule} from 'primeng/calendar';
import {CheckboxModule} from 'primeng/checkbox';
import { AlertMessage } from './services/alertmessage.service';
import { MessageService } from 'primeng/api';
import {ToastModule} from 'primeng/toast';
import {InputTextModule} from 'primeng/inputtext';
import {DropdownModule} from 'primeng/dropdown';
import {TableModule} from 'primeng/table';
import {HeaderDirective } from './directives/header';
import { ContainerDirective} from "./Directives/container";
import { FooterDirective } from "./Directives/footer";
import { BodyDirective} from "./Directives/body";
import {SideMenuDirective} from "./Directives/side-menu";
import {InputMaskModule} from 'primeng/inputmask';
import {TooltipModule} from 'primeng/tooltip';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { MethodDetailsComponent } from './components/method-details/method-details.component';
import { StorageServiceModule} from 'angular-webstorage-service';
import { AppServiceService } from '../app/shared/app-service.service';
import {SidebarModule} from 'primeng/sidebar';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import {ChartModule} from 'primeng/chart';
import { ReportsComponent } from './components/reports/reports.component';
import {FileUploadModule} from 'primeng/fileupload';
import {CardModule} from 'primeng/card';

@NgModule({
  declarations: [
    AppComponent,
    MethodrequestComponent,
    DashboardComponent,
    UserComponent,
    HeaderDirective,
    ContainerDirective,
    FooterDirective,
    BodyDirective,
    SideMenuDirective,
    MethodDetailsComponent,
    ReportsComponent
   
  ],
  imports: [
    BrowserModule,
    StorageServiceModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    MultiSelectModule,
    BrowserAnimationsModule,
    CalendarModule,
    CheckboxModule,
    ToastModule,
    InputTextModule,
    DropdownModule,
    TableModule,
    InputMaskModule,
    TooltipModule,
    AutoCompleteModule,
    SidebarModule,
    OverlayPanelModule,
    MessagesModule,
    MessageModule,
    FileUploadModule,
    CardModule,
    ChartModule
    //BsDatepickerModule.forRoot()
  ],
  providers: [MethodService, Methodetailservice, AlertMessage, MessageService, { provide: APP_BASE_HREF, useValue: '/teams/MethodsDBST/SitePages/methods.aspx#' }],
  // providers: [MethodService, AlertMessage, MessageService, { provide: APP_BASE_HREF, useValue: '/teams/MethodsDBDev1/SitePages/method.aspx#' }],

    //providers: [MethodService,Methodetailservice,AppServiceService, AlertMessage, MessageService, { provide: APP_BASE_HREF, useValue: '/teams/MethodsDBD/_layouts/15/workbench.aspx#/' }],
  
  entryComponents: [AppComponent]
})
export class AppModule {
  constructor() {
  }
  // ngDoBootstrap() { }
  ngDoBootstrap(appRef: ApplicationRef) {
    const rootElements = document.querySelectorAll('app-root');
    for (const element of rootElements as any as HTMLElement[]) {
      appRef.bootstrap(AppComponent, element);
    }
  }
}
