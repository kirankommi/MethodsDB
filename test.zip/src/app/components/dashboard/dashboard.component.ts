import { Component, OnInit, Input } from '@angular/core';
import { WebPartContext } from '@microsoft/sp-webpart-base';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { Router } from '@angular/router';
import { DashboardModel, DashboardExportModel, DashboardTeamadtl } from '../../models/DashboardModel';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import { element } from 'protractor';
import { elementEnd } from '@angular/core/src/render3/instructions';
const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  searchDisplay: boolean = false;
  Tab: string = "grid";
  searchTab: string = "advanced";
  @Input() context: WebPartContext;
  currentWebUrl: string = '';
  reqList: DashboardModel[];
  fullReqestList: DashboardModel[];
  TeamadnldtList: DashboardTeamadtl[];
  cols: any[];
  searchTitle: string;
  searchReqNo: string;
  ddlStatus: string = "";
  searchGrouparea: string;
  searchFstname:string;
  searchLstname:string;
  lstWorkGroupArea: any;
  MAAuthors: any;
  lstTeamPriority: any;
  lstTeamStatus:any;
  
  //Search For Requestpool//
  SearchTitle_RP: string;


  exportreqlist: DashboardExportModel[] = [];

  constructor(private router: Router) { }

  ngOnInit() {
    this.context = window["webPartContext"];
    this.currentWebUrl = this.context.pageContext.web.absoluteUrl;
    this.getMethodRequests();



    this.cols = [
      { field: 'Id', header: 'REQUEST #' },
      { field: 'Title', header: 'TITLE' },
      { field: 'Status', header: 'STATUS' },
      { field: 'WorkGroupArea', header: 'GROUP AREA' },
      { field: 'AuthorFirstName', header: 'AUTHOR FIRST NAME' },
      { field: 'AuthorLastName', header: 'LAST NAME' },
      { field: 'Priority', header: 'PRIORITY' },
    ];
  }
  async mapAuthor() {
    await this.reqList.map((element) => {
      this.getAuthorDetails(element); 
    });
    this.reqList.map((element: any, index: number) => {

    });

  }
  getAuthorDetails(req: any) {
    if(req.MAAuthorsId != undefined){
      let requestUrl = this.currentWebUrl.concat('/_api/web/getuserbyid(' + "'" + req.MAAuthorsId + "'" + ')');
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null) {
              req.MAAuthors = responseJSON.Title;
              req.AuthorFirstName = req.MAAuthors.split(',')[1];
              req.AuthorLastName = req.MAAuthors.split(',')[0];
            }
          });
        }
      });
    }
  }
  getMethodRequests() {
    let requestLibrary = 'lstMethodRequest';
    let requestUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + requestLibrary + "'" + ')/items')
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.reqList = responseJSON.value;
              this.reqList.sort((a, b) => b.Id - a.Id);
              this.fullReqestList = responseJSON.value;
              this.getTeamAdditionalDtls();
            }
          });
        }
      });
  }

  getTeamAdditionalDtls() {
    let requestLibrary = 'lstTeamAdditionalDtls';
    let requestUrl = this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + requestLibrary + "'" + ')/items')
    this.context.spHttpClient.get(requestUrl, SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.TeamadnldtList = responseJSON.value;
              this.reqList.forEach(element => {
                this.TeamadnldtList.map(x => {
                  if (x.Title == element.Id) {
                    if(x.Title != null && x.Title != undefined){
                      element.MAAuthorsId = x.MAAuthorId;
                      element.WorkGroupAreaId = x.WorkGroupAreaId;
                      element.PriorityId = x.PriorityId;
                      element.RequestStatusId = x.RequestStatusId;
                      this.mapAuthor();
                      this.GetLists();
                    }
                  }
                })
              });
              this.fullReqestList = this.reqList;
            }
          });
        }
      });
  }

  GetLists() {

    let WorkGroupArea = 'lstWorkGroupArea';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + WorkGroupArea + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstWorkGroupArea = responseJSON.value;
            }
           
            this.reqList.map(x => {
              this.lstWorkGroupArea.forEach(element => {
                if (element.Id == x.WorkGroupAreaId) {
                  x.WorkGroupArea = element.Title;

                }
              });
              
            });
          });
        }
      });

    let TeamPriority = 'lstTeamPriority';
    this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + TeamPriority + "'" + ')/items'), SPHttpClient.configurations.v1)
      .then((response: SPHttpClientResponse) => {
        if (response.ok) {
          response.json().then((responseJSON) => {
            if (responseJSON != null && responseJSON.value != null) {
              this.lstTeamPriority = responseJSON.value;
              this.reqList.map(x => {
                this.lstTeamPriority.forEach(element => {
                  if (element.Id == x.PriorityId && x.MAAuthorsId != null && x.MAAuthorsId != undefined) {
                    x.Priority = element.Title;
                    //this.fullReqestList=responseJSON.value;
                  }
                });

              });
            }

          });
        }
      });

      let TeamStatus = 'lstRequestStatus';
      this.context.spHttpClient.get(this.currentWebUrl.concat('/_api/web/Lists/GetByTitle(' + "'" + TeamStatus + "'" + ')/items'), SPHttpClient.configurations.v1)
        .then((response: SPHttpClientResponse) => {
          if (response.ok) {
            response.json().then((responseJSON) => {
              if (responseJSON != null && responseJSON.value != null) {
                this.lstTeamStatus = responseJSON.value;
                this.reqList.map(x => {
                  this.lstTeamStatus.forEach(element => {
                    if (element.Id == x.RequestStatusId && x.RequestStatusId != null && x.RequestStatusId != undefined) {
                      x.Status = element.Title;
                      //this.fullReqestList=responseJSON.value;
                    }
                  });
  
                });
              }
  
            });
          }
        });

  }

  redirectToRequests(Id) {
    this.router.navigateByUrl('/methodetails/' + Id);
  }

  search() {
    this.reqList = []
    this.reqList = this.fullReqestList;
    if (this.searchTitle != '' && this.searchTitle != null && this.searchTitle != undefined) {
      this.reqList = this.reqList.filter(s => (s.Title.toLocaleLowerCase().includes(this.searchTitle.toLocaleLowerCase().trim())));
    }
    if (this.searchReqNo != '' && this.searchReqNo != null && this.searchReqNo != undefined) {
      this.reqList = this.reqList.filter(s => (s.Id.toString() == this.searchReqNo));
    }
    if (this.ddlStatus != '' && this.ddlStatus != null && this.ddlStatus != undefined) {
      this.reqList = this.reqList.filter(s => (s.Status == this.ddlStatus));
    }
    if (this.searchGrouparea != '' && this.searchGrouparea != null && this.searchGrouparea != undefined) {
      this.reqList = this.reqList.filter(s => (s.WorkGroupArea != undefined ? s.WorkGroupArea.toLocaleLowerCase().includes(this.searchGrouparea.toLocaleLowerCase().trim()) : false));
    }
    if(this.searchFstname !='' && this.searchFstname !=null && this.searchFstname !=undefined){
      this.reqList=this.reqList.filter(s=>(s.AuthorFirstName != undefined ? s.AuthorFirstName.toLocaleLowerCase().includes(this.searchFstname.toLocaleLowerCase().trim()) : false))
    }
    if(this.searchLstname !='' && this.searchLstname !=null && this.searchLstname !=undefined){
      this.reqList=this.reqList.filter(s=>(s.AuthorLastName != undefined ? s.AuthorLastName.toLocaleLowerCase().includes(this.searchLstname.toLocaleLowerCase().trim()) : false))
    }
  }

  cancel() {
    this.searchTitle = null;
    this.searchReqNo = null;
    this.ddlStatus = "";
    this.searchGrouparea = null;
    this.searchFstname=null;
    this.searchLstname=null;
    this.getMethodRequests();
  }
  exportExcel() {
    this.exportreqlist = [];
    for (let i = 0; i < this.reqList.length; i++) {
      this.exportreqlist.push({
        'REQUEST #': this.reqList[i].Id,
        'TITLE': this.reqList[i].Title,
        'STATUS': this.reqList[i].Status,
        'GROUP AREA': this.reqList[i].WorkGroupArea,
        'AUTHOR FIRST NAME':this.reqList[i].AuthorFirstName,
        'LAST NAME':this.reqList[i].AuthorLastName,
        'PRIORITY': this.reqList[i].Priority,
      })
    }
    import("xlsx").then(xlsx => {
      const worksheet = xlsx.utils.json_to_sheet(this.exportreqlist);
      const workbook = { Sheets: { 'RequestPool': worksheet }, SheetNames: ['RequestPool'] };
      const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });
      this.saveAsExcelFile(excelBuffer, "RequestPool");
    });
  }

  saveAsExcelFile(buffer: any, fileName: string): void {
    import("file-saver").then(FileSaver => {
      let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
      let EXCEL_EXTENSION = '.xlsx';
      const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE
      });
      FileSaver.saveAs(data, fileName);
    });
  }

  RequestPool_Search() {
    this.reqList = []
    this.reqList = this.fullReqestList;
    if (this.SearchTitle_RP != '' && this.SearchTitle_RP != null && this.SearchTitle_RP != undefined) {
      this.reqList = this.reqList.filter(s => (
        s.Title.toLocaleLowerCase().includes(this.SearchTitle_RP.toLocaleLowerCase().trim())
        || s.Status.toLocaleLowerCase().includes(this.SearchTitle_RP.toLocaleLowerCase().trim())
        || (s.Id.toString() == this.SearchTitle_RP)
        || (s.WorkGroupArea != undefined ? s.WorkGroupArea.toLocaleLowerCase().includes(this.SearchTitle_RP.toLocaleLowerCase().trim()) : false)
        || (s.Priority != undefined ? s.Priority.toLocaleLowerCase().includes(this.SearchTitle_RP.toLocaleLowerCase().trim()) : false)
        || (s.AuthorFirstName != undefined ? s.AuthorFirstName.toLocaleLowerCase().includes(this.SearchTitle_RP.toLocaleLowerCase().trim()) : false)
        || (s.AuthorLastName != undefined ? s.AuthorLastName.toLocaleLowerCase().includes(this.SearchTitle_RP.toLocaleLowerCase().trim()) : false)
      ));
    }

  }

}
