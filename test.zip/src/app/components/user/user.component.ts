import { Component, OnInit } from '@angular/core';
// import { DashboardService} from '../../services/dashboard/dashboard.service'
// import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/finally';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    // this.service.GetGeneralInfo().subscribe(
    //   result => {
    //     // Handle result
    //     console.log(result)
    //   },
    //   error => {
       
    //   },
    //   () => {
    //     // 'onCompleted' callback.
    //     // No errors, route to new page here
    //   }
    // );
    }
}
