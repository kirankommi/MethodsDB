﻿
export class ErrorMessage {
    public Id: string;
    public Title: string;
    public Details: any;
    public Error: any;
}