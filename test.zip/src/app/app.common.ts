export interface IListItemEntityType {
    ListItemEntityTypeFullName: string;
    
  }
  
  export interface IRequestDigest {
    FormDigestValue: string;
  }

  export interface IHttpPromiseCallbackArg
  {
    headers:any;
  }