export interface PeoplePickerQuery {
    queryParams: PeoplePickerQueryParams;
}
export interface PeoplePickerQueryParams {
    QueryString: string;
    MaximumEntitySuggestions: number;
    AllowEmailAddressess: boolean;
    AllowOnlyEmailAddressess: boolean;
    PrinciplaType: number;
    PrinciplaSource: number;
    SharePointGroupId: number;
}
export interface FormDigestResponse {
    'odata.metdata': string;
    FormDigestTimeOutSeconds: number;
    FormDigestValue: string;
    LibraryVersion: number;
    SiteFullUrl: string;
    SupportedSchemaVersions: string[];
    WebFullUrl: string;
}
export interface PeoplePickerResponse {
    d: PeoplePickerData;
}
interface PeoplePickerData{
ClientPeoplePickerSearchUser: PeoplePickerUser[];
}
export interface PeoplePickerUser {
    Key: string;
    Description: string;
    DisplayText: string;
    EntityType: string;
    ProvideDisplayName: string;
    ProviderName: string;
    IsResolved: boolean;
    EntityData: PeoplePickerUserEntityData;
    MultipleMatches: any[];
}
export interface PeoplePickerUserEntityData {
    IsAlSecIdPresent: boolean;
    Title: string;
    Email: string;
    MobilePhone: number;
    ObjectId: string;
    Department: string;
}