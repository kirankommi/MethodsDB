import { Component, OnInit } from '@angular/core';
import { Message } from 'primeng/primeng';
@Component({
    //moduleId: module.id,
    selector: 'fdms-footer',
    templateUrl: 'footer.html'
})

export class FooterDirective implements OnInit {
    version: string
    constructor() {

    }
    ngOnInit() {
        this.GetVersion();
    }
    GetVersion() {
        
    }
}
