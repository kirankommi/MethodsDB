import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise'
import { observableToBeFn } from 'rxjs/testing/TestScheduler';
import {IRequestDigest,IListItemEntityType,IHttpPromiseCallbackArg} from '../app.common';
import { Lab_centers, } from '../models/RequestorModel';

@Injectable()
export class MethodService {
  public currentItem: any;
  listItemEntityTypeName: string = '';
  formDigestValue: string = '';

  //url: string = 'https://honeywellprod.sharepoint.com/teams/MethodsDBD';
  url: string = 'https://honeywellprod.sharepoint.com/teams/MethodsDBST';
  listName = 'lstMethodRequest';

  constructor(private http: HttpClient) {
    this.listName = 'lstMethodRequest';
  }

  public readItems(): Observable<any> {
    const headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
    const requestOptions = {headers: headers};
    return this.http.get(this.url+'/_api/web/lists/getbytitle('+"'"+this.listName+"'"+')/items', requestOptions);
  }
  public getUser(): Observable<any> {
    const headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
    const requestOptions = {headers: headers};
    return this.http.get(this.url+'/_api/web/currentuser', requestOptions);
  }
  private getRequestDigest(): Promise<any> {
    let promise = new Promise((resolve, reject) => {
      const headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
      const requestOptions = {headers: headers};
      this.http.post(this.url + '/_api/contextinfo', '', requestOptions).toPromise().then((res: IRequestDigest) => { this.formDigestValue = res.FormDigestValue; resolve(); });
    });
    return promise;
  }

  public getListItemEntityTypeName(listname: string): Promise<any> {
    let promise = new Promise((resolve, reject) => {
      const headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
      const requestOptions = {headers: headers};
      this.http.get(this.url+'/_api/web/lists/getbytitle('+"'"+listname+"'"+')?$select=ListItemEntityTypeFullName', requestOptions
      ).toPromise().then((res: IListItemEntityType) => { console.log(res);this.listItemEntityTypeName = res.ListItemEntityTypeFullName; resolve(); });
    });
    return promise;
  }

  public createItem(Id:number, title: string, Date_Requested: Date, Requester: string, Phone: number,RequestorEmail:string,Sched_A_934_Eng:boolean,
    Tech_Service:boolean,Manfacturing:boolean,
    Instrumentation:boolean,Training:boolean,Others:boolean, OthersData:string, Lab_centers:number[], PlantsAffectedArray:number[], Request_Type:string, Priority:string,
    Source_of_request:string, Sample_Matrix:number[], Proj_Activity:string, Cost_Center:string, Problem_Statement:string,
    Change_Requested:string, Business_Need:string, Additional_Info:string, Safety_concerns:string, Component_Limit_of_Detection:string,
    Matrix_Stream_Composition:string, Matrix_Stram_Concenration_Range:string, StatusId: string): Promise<any> {
    let user= this.getUser();
    console.log(user);
    debugger;
    let promise = new Promise((resolve, reject) => {
      this.getListItemEntityTypeName(this.listName)
        .then((res) => {
          return this.getRequestDigest();
        })
        .then((res) => {
          let headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
          headers = headers.set('Content-type', 'application/json;odata=verbose');
          headers = headers.set('X-RequestDigest', this.formDigestValue);
          const requestOptions = {
            headers: headers
          };
          const body: string = JSON.stringify({
            '__metadata': {
              'type': this.listItemEntityTypeName
            },
            'Title': title,
            'Date_Requested': Date_Requested,
            'Requester':Requester,
            'Phone': Phone,
            'RequestorEmail': RequestorEmail,
            'SchedA_934_Eng': Sched_A_934_Eng,
            'Tech_Service':Tech_Service,
            'Manufacturing':Manfacturing,
            'Instrumentation':Instrumentation,
            'Training':Training,
            'Others':Others,
            'OthersData': OthersData,
            'LabCentersId':{ "results":Lab_centers},
            'PlantsAffectedId': { "results":PlantsAffectedArray},//PlantsAffectedId,
            'Request_TypeId':Request_Type,
            'PriorityId':Priority,
            'Source_of_RequestId':Source_of_request == '' ? 0 : Source_of_request,
            'Sample_MatrixId':{ "results":Sample_Matrix},
            'Project_Activity':Proj_Activity,
            'Cost_Center':Cost_Center,
            'Problem_Statement':Problem_Statement,
            'Change_Requested':Change_Requested,
            'Business_Need':Business_Need,
            'Additional_Info':Additional_Info,
            'Safety_concerns':Safety_concerns,
            'Component_Limit_of_Detection':Component_Limit_of_Detection,
            'Matrix_StreamComposition':Matrix_Stream_Composition,
            'Matrix_StreamConcentrationRange':Matrix_Stram_Concenration_Range,
            'Status': 'Active'
          });
          this.http.post(this.url+'/_api/web/lists/getbytitle('+"'"+this.listName+"'"+')/items',
          body, requestOptions).toPromise().then(res => { resolve(); });
          
        });
    });
    return promise;
  }

  public readItem(id: number): Promise<any> {
    let promise = new Promise((resolve, reject) => {
      let headers = new HttpHeaders().set('accept', 'application/json');
      const requestOptions = {
        headers: headers
      };
      this.http.get(this.url+'/_api/web/lists/getbytitle('+"'"+this.listName+"'"+')/items(${id})', requestOptions).toPromise()
        .then((response) => { this.currentItem = response;
          resolve();
        }, (error: any): void => {
          reject(error);
        });
    });
    return promise;
  }

  public updateItem(Id:number, title: string, Date_Requested: Date, Requester: string, Phone: number ,RequestorEmail:string,Sched_A_934_Eng:boolean,
    Tech_Service:boolean,Manfacturing:boolean,
    Instrumentation:boolean,Training:boolean,Others:boolean, OthersData:string,Lab_centers:number[], PlantsAffectedArray:number[], Request_Type:string, Priority:string,
    Source_of_request:string, Sample_Matrix:number[], Proj_Activity:string, Cost_Center:string, Problem_Statement:string,
    Change_Requested:string, Business_Need:string, Additional_Info:string, Safety_concerns:string, Component_Limit_of_Detection:string,
    Matrix_Stream_Composition:string, Matrix_Stram_Concenration_Range:string, StatusId: string): Promise<any> {
      console.log("ID" + Id);  
    let promise = new Promise((resolve, reject) => {
      let listItemEntityTypeName: string = undefined;
      this.getListItemEntityTypeName(this.listName)
        .then((res) => {
          debugger;
          return this.getRequestDigest();
        })
        .then((res) => {
          debugger;
          let headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
          headers = headers.set('Content-type', 'application/json;odata=verbose');
          headers = headers.set('X-RequestDigest', this.formDigestValue);
          headers = headers.set('X-HTTP-Method', 'MERGE');
          headers = headers.set('Access-Control-Allow-Origin', '*');
          headers = headers.set('IF-MATCH', this.currentItem["odata.etag"]);
          const requestOptions = {
            headers: headers
          };
          
          const body: string = JSON.stringify({
            '__metadata': {
              'type': this.listItemEntityTypeName
            },
            'Title': title,
            'Date_Requested': Date_Requested,
            'Requester':Requester,
            'Phone': Phone,
            'RequestorEmail': RequestorEmail,
            'SchedA_934_Eng': Sched_A_934_Eng,
            'Tech_Service':Tech_Service,
            'Manufacturing':Manfacturing,
            'Instrumentation':Instrumentation,
            'Training':Training,
            'Others':Others,
            'OthersData': OthersData,
            'LabCentersId':{ "results":Lab_centers},
            'PlantsAffectedId':{ "results":PlantsAffectedArray},
            'Request_TypeId':Request_Type,
            'PriorityId':Priority,
            'Source_of_RequestId':Source_of_request == '' ? 0 : Source_of_request,
            'Sample_MatrixId':{ "results":Sample_Matrix},
            'Project_Activity':Proj_Activity,
            'Cost_Center':Cost_Center,
            'Problem_Statement':Problem_Statement,
            'Change_Requested':Change_Requested,
            'Business_Need':Business_Need,
            'Additional_Info':Additional_Info,
            'Safety_concerns':Safety_concerns,
            'Component_Limit_of_Detection':Component_Limit_of_Detection,
            'Matrix_StreamComposition':Matrix_Stream_Composition,
            'Matrix_StreamConcentrationRange':Matrix_Stram_Concenration_Range,
            'Status': 'Active-Request'
          });
          this.http.post(this.url+'/_api/web/lists/getbytitle('+"'"+this.listName+"'"+')/items('+Id+')?@target='+this.url,
            body, requestOptions).toPromise().then(res => { this.currentItem = null; resolve(); });
        });
    });
    return promise;
  }

  public deleteItem(id: number): Promise<any> {
    let promise = new Promise((resolve, reject) => {
      this.getRequestDigest()
        .then((res) => {
          console.log(this.formDigestValue);
          let headers = new HttpHeaders().set('accept', 'application/json;odata=nometadata');
          headers = headers.set('Content-type', 'application/json;odata=verbose');
          headers = headers.set('X-RequestDigest', this.formDigestValue);
          headers = headers.set('X-HTTP-Method', 'DELETE');
          headers = headers.set('IF-MATCH', this.currentItem["odata.etag"]);
          const requestOptions = {
            headers: headers
          };
          const body: string = JSON.stringify({
            'Id': id
          });
          return this.http.post(this.url+'/_api/web/lists/getbytitle('+"'"+this.listName+"'"+')/items(${id})', body,
            requestOptions).toPromise().then(res => { this.currentItem = null; resolve(); });
        });
    });
    return promise;
  }
}
