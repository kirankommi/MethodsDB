export class DashboardModel {
    Id: number;
    Date_Requested: Date;
    Title: string;
    Status: string;
    PriorityId: number;
    Priority: string;
    WorkGroupAreaId: number;
    WorkGroupArea: string;
    AuthorFirstName: string;
    AuthorLastName: string;
    MAAuthors: string;
    MAAuthorsId: number;
    RequestStatusId: number;
}

export class DashboardExportModel {
    'REQUEST #': number;
    TITLE: string;
    STATUS: string;
    'GROUP AREA': string;
    'AUTHOR FIRST NAME': string;
    'LAST NAME': string;
    'PRIORITY': string;
}

export class DashboardTeamadtl {
    Title: number;
    PriorityId: number;
    WorkGroupAreaId: number;
    MAAuthorId: number;
    RequestStatusId: number;
}