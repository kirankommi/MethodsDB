export class RequestTypes {
    Id:number;
    Title: string;
}

export class SampleMatrix{
    Id:number;
    Title: string;
}

export class Lab_centers{
    Id:number;
    Title: string;
}
export class PlantsAffected{
    Id:number;
    Title: string;
}

export class Priorities{
    Id:number;
    Title: string;
}
export class lstSource_of_Request{
    Id:number;
    Title: string;
}

export class RequestorModel
{
    Id:number;
    Date_Requested:Date;
    Requester:string;
    Phone:number;
    RequestorEmail:string;
    SchedA_934_Eng:boolean;
    Tech_Service:boolean;
    Manufacturing:boolean;
    Instrumentation:boolean;
    Training:boolean;
    Others:boolean;
    OthersData: string;
    LabCentersId:number[];
    PlantsAffectedId:number[];
    Request_TypeId:string;
    PriorityId:string;
    Source_of_RequestId:string;
    Sample_MatrixId:number[];
    Project_Activity:string;
    Cost_Center:string;
    Title:string;
    Problem_Statement:string;
    Change_Requested:string;
    Business_Need:string;
    Additional_Info:string;
    Safety_concerns:string;
    Component_Limit_of_Detection:string;
    Matrix_StreamComposition:string;
    Matrix_StreamConcentrationRange:string;
    StatusId: string;
}

