export class lstTeamPriority{
    Id:number;
    Title: string;
}

export class lstWorkGroupArea{
    Id:number;
    Title: string;
}

export class lstRequestStatus{
    Id:number;
    Title: string;
}

export class lstMethodStatus{
    Id:number;
    Title: string;
}

export class lstClassificationReviewers{
    Id:number;
    Title: string;
}

export class lstClassificationType{
    Id:number;
    Title: string;
}

export class lstLabManagers {
    Id:number;
    Title: string;
}

export class lstAnalyticalManagers {
    Id:number;
    Title: string;
}

export class lstAuthors {
    Id:number;
    Title: string;
}

export class lstTechExperts {
    Id:number;
    Title: string;
}

export class TeamDetatails {
    Id:number;
    TechArea: string;
    TechDeliveryDate: string;
    PriorityId: number;
    WorkGroupAreaId: number;
    RequestStatusId: number;
    MethodNo: string;
    VersionNo: string;
    Classification: string;
    ReValidation: string;
    MethodType: string;
    MethodStatusId: number;
    ClassificationReviewers: string;
    MRLabManager: string;
    MRAnalyticalManager: string;
    MRAuthor: string;
    MRTechExperts: string;
    MALabManager: string;
    MAAnalyticalManager: string;
    MAAuthor: string;
    MATechExperts: string;
}
export class GenericManagers {
    
    value:number;
    label: string;
} 

export class MRLabManagerModel {
    Id: number;
    Reply: boolean;
    Email: string;
}
export class classificationReviewersArray {
    RowId: number;
    Id: number;
    Type: number;
    Reply: boolean;
    Email: string;
    Title: string;
}
export class classificationReviewersDropDown
{

}
export class selectedClassRevs {
    Id:number;
}