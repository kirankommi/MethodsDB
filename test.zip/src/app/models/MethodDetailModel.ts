export class MethodDtlsModel
{
    Id:number;
    Date_Requested:Date;
    Requester:string;
    Phone:number;
    RequestorEmail:string;
    SchedA_934_Eng:boolean;
    Tech_Service:boolean;
    Manufacturing:boolean;
    Instrumentation:boolean;
    Training:boolean;
    Others:boolean;
    OthersData: string;
    LabCentersId:number[];
    PlantsAffectedId:number[];
    Request_TypeId:string;
    PriorityId:string;
    Source_of_RequestId:string;
    Sample_MatrixId:number[];
    Project_Activity:string;
    Cost_Center:string;
    Title:string;
    Problem_Statement:string;
    Change_Requested:string;
    Business_Need:string;
    Additional_Info:string;
    Safety_concerns:string;
    Component_Limit_of_Detection:string;
    Matrix_StreamComposition:string;
    Matrix_StreamConcentrationRange:string;

}

export class MethodNotes {
    Title:string;
    Header:string;
    Description:string;
    Indicator:string;
    Id: number;
}
