export class Teamadtls {
    Id: number;
    VersionNo: string;
    MethodType: string;
    Title: string;
    MethodNo: string;
}