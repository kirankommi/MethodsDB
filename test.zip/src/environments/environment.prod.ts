export const environment = {
  production: true,
  web: 'https://honeywellprod.sharepoint.com/teams/MethodsDBD/'
};
