// import '../main';
import { SPComponentLoader } from '@microsoft/sp-loader';
import { AppComponent } from '../app/app.component';
import * as router from '@angular/router';
import { Version } from '@microsoft/sp-core-library';
// import  appService from '../app/services/dashboard/dashboard.service';
import appService from './appWebPart.service';
import 'reflect-metadata';
import { MultiSelectModule } from 'primeng/primeng';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
// @ts-ignore
import { AppModuleNgFactory } from '../app/app.module.ngfactory';
import {
    SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions
} from '@microsoft/sp-http';
import {
    Environment,
    EnvironmentType
} from '@microsoft/sp-core-library';
import {
    BaseClientSideWebPart,
    IPropertyPaneConfiguration,
    PropertyPaneTextField
} from '@microsoft/sp-webpart-base';
import { debug } from 'util';
import { AppModule } from '../app/app.module';
import 'reflect-metadata';
require('zone.js'); 

export default class NgHelloWorldWebPartWebPart extends BaseClientSideWebPart<AppComponent> {
    constructor() {
        super();
    }
    
    ngElement: HTMLElement;

    public render(): void {
   
        window['webPartContext'] = this.context;
        
        let styleUrl2 = 'https://honeywellprod.sharepoint.com/:u:/r/teams/MethodsDBD/MethodsDBAssets/WebPartAssets/Styles/controls.css';
        let styleUrl3 = 'https://honeywellprod.sharepoint.com/:u:/r/teams/MethodsDBD/MethodsDBAssets/WebPartAssets/Styles/font-awesome.min.css';
        let styleUrl4 = 'https://honeywellprod.sharepoint.com/:u:/r/teams/MethodsDBD/MethodsDBAssets/WebPartAssets/Styles/app.css';
        let cssUrl = 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css';
        let primeCss1='https://honeywellprod.sharepoint.com/:u:/r/teams/MethodsDBD/MethodsDBAssets/WebPartAssets/primeng/primeicons.css';
        let primeCss2='https://honeywellprod.sharepoint.com/:u:/r/teams/MethodsDBD/MethodsDBAssets/WebPartAssets/primeng/Themes/theme.css';
        let primeCss3='https://honeywellprod.sharepoint.com/:u:/r/teams/MethodsDBD/MethodsDBAssets/WebPartAssets/primeng/primeng.min.css';
        let primengchartjs='https://honeywellprod.sharepoint.com/:u:/r/teams/MethodsDBD/MethodsDBAssets/WebPartAssets/primeng/Chart.js';
        let primengchartcss='https://honeywellprod.sharepoint.com/:u:/r/teams/MethodsDBD/MethodsDBAssets/WebPartAssets/primeng/Chart.css';
        
        
        SPComponentLoader.loadCss(styleUrl2);
        SPComponentLoader.loadCss(styleUrl3);
        SPComponentLoader.loadCss(styleUrl4);
        SPComponentLoader.loadCss(cssUrl);
        SPComponentLoader.loadCss(primeCss1);
        SPComponentLoader.loadCss(primeCss2);
        SPComponentLoader.loadCss(primeCss3);
        SPComponentLoader.loadScript(primengchartjs);
        SPComponentLoader.loadCss(primengchartcss);

        this.domElement.innerHTML = `<app-root description='` + this.properties.description + `'></app-root>`;
        platformBrowserDynamic().bootstrapModuleFactory(
            AppModuleNgFactory)
            .catch(
                err => console.log(err));
        // this._renderListAsync();
        // this._getUser();
        let ngElement = this.domElement.getElementsByTagName('app-methodrequest')[0]

        if (ngElement) {
            this.domElement.removeChild(ngElement);
        }

        // const ElementListRest = customElements.get('app-methodrequest');
        // const element = new ElementListRest();
        // element.context = this.context;
        // this.domElement.appendChild(element);
    }

    private _renderListAsync(): void {

        appService.getListData(this.context)
            .then((response) => {
                console.log(response);
            });
    }
    private _getUser(): void {
        appService.getUserName(this.context).then((response) => { console.log(response); })
    }
    protected get dataVersion(): Version {
        return Version.parse('1.0');
    }

    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
        return {
            pages: [
                {
                    header: {
                        description: 'Description'
                    },
                    groups: [
                        {
                            groupName: 'Options',
                            groupFields: [
                                PropertyPaneTextField('description', {
                                    label: 'Description',
                                    value: 'Methods'
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    }
}
