import {
    SPHttpClient, SPHttpClientResponse, ISPHttpClientOptions
} from '@microsoft/sp-http';
// import { Injectable } from '@angular/core';
// @Injectable()
export default class AppService{
    static getListData(context: any): Promise<any> {
        return context.spHttpClient.get(context.pageContext.web.absoluteUrl + "/_api/web/lists/GetByTitle('lstLabCenter')/Items", SPHttpClient.configurations.v1)
            .then((response: SPHttpClientResponse) => {
                console.log(response);
                return response.json();
            });
    }
    static getUserName(context: any): Promise<any> {
        return context.spHttpClient.get(context.pageContext.web.absoluteUrl + "/_api/web/currentuser", SPHttpClient.configurations.v1)
            .then((response: SPHttpClientResponse) => {
                console.log(response);
                return response.json();
            });
    }
    static postListData(data: any,context: any){
        console.log(context);
       
    }
}